import os
import re
import json
import base64
import secrets
import hashlib
import hmac
import random
import string
import urllib.parse
from pathlib import Path
from datetime import datetime, timedelta, date
from typing import Optional, List, Dict, Any

from fastapi import FastAPI, Depends, HTTPException, status, Query, Request, Response, Cookie
from fastapi.responses import FileResponse
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from fastapi.middleware.cors import CORSMiddleware
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.staticfiles import StaticFiles
from starlette.middleware.trustedhost import TrustedHostMiddleware
from pydantic import BaseModel, EmailStr, ConfigDict, Field
from sqlalchemy import (
    create_engine, Column, Integer, String, Float, ForeignKey, Text, Boolean,
    DateTime as SQLDateTime, event, and_, or_, func, UniqueConstraint
)
from sqlalchemy.orm import declarative_base, sessionmaker, relationship, Session
from passlib.context import CryptContext
from jose import JWTError, jwt

try:
    from dotenv import load_dotenv
    load_dotenv()
except Exception:
    pass

try:
    from openai import OpenAI
except Exception:
    OpenAI = None

try:
    from google import genai
except Exception:
    genai = None

# -----------------------------------------------------------------------------
# APP / CONFIG
# -----------------------------------------------------------------------------
BASE_DIR = Path(__file__).resolve().parent
INDEX_PATH = BASE_DIR / "index.html"
ASSETS_DIR = BASE_DIR / "assets"
ENVIRONMENT = os.getenv("SUPPLY_AI_ENV", "development").strip().lower()
IS_PRODUCTION = ENVIRONMENT == "production"

def resolve_app_path(value: str, default: Path) -> Path:
    """Resolve configurable data paths without allowing an implicit web-root path."""
    candidate = Path(value).expanduser() if value else default
    return candidate.resolve() if candidate.is_absolute() else (BASE_DIR / candidate).resolve()

DB_PATH = resolve_app_path(os.getenv("SUPPLY_AI_DATABASE_PATH", ""), BASE_DIR / "supply_ai.db")
DATABASE_URL = f"sqlite:///{DB_PATH.as_posix()}"
UPLOAD_STORAGE_DIR = resolve_app_path(os.getenv("SUPPLY_AI_UPLOAD_DIR", "uploads"), BASE_DIR / "uploads")
MAX_UPLOAD_BYTES = int(os.getenv("SUPPLY_AI_MAX_UPLOAD_BYTES", str(10 * 1024 * 1024)))

SECRET_KEY = os.getenv("SUPPLY_AI_SECRET_KEY", "").strip()
if not SECRET_KEY or len(SECRET_KEY) < 32:
    raise RuntimeError(
        "SUPPLY_AI_SECRET_KEY is required and must be at least 32 characters long. "
        "Generate one with: python -c \"import secrets; print(secrets.token_hex(32))\""
    )

ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = int(os.getenv("SUPPLY_AI_ACCESS_TOKEN_MINUTES", "15"))
REFRESH_TOKEN_EXPIRE_DAYS = int(os.getenv("SUPPLY_AI_REFRESH_TOKEN_DAYS", "30"))
REFRESH_COOKIE_NAME = os.getenv("SUPPLY_AI_REFRESH_COOKIE_NAME", "cauldra_refresh")
REFRESH_COOKIE_SECURE = os.getenv("SUPPLY_AI_REFRESH_COOKIE_SECURE", "true" if IS_PRODUCTION else "false").strip().lower() == "true"
REFRESH_COOKIE_SAMESITE = os.getenv("SUPPLY_AI_REFRESH_COOKIE_SAMESITE", "lax").strip().lower()
TRUSTED_HOSTS = [x.strip() for x in os.getenv("SUPPLY_AI_TRUSTED_HOSTS", "").split(",") if x.strip()]
RATE_LIMIT_WINDOW_SECONDS = int(os.getenv("SUPPLY_AI_RATE_LIMIT_WINDOW_SECONDS", "300"))
RATE_LIMIT_MAX_FAILURES = int(os.getenv("SUPPLY_AI_RATE_LIMIT_MAX_FAILURES", "8"))
FORGOT_CODE_TTL_SECONDS = int(os.getenv("SUPPLY_AI_FORGOT_CODE_TTL", "600"))
FORGOT_RESEND_SECONDS = int(os.getenv("SUPPLY_AI_FORGOT_RESEND", "60"))
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-5")
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-3.5-flash")
TERMII_BASE_URL = os.getenv("TERMII_BASE_URL", "https://api.ng.termii.com").rstrip("/")
RESEND_FROM = os.getenv("RESEND_FROM", "onboarding@resend.dev")
PAYSTACK_SECRET_KEY = os.getenv("PAYSTACK_SECRET_KEY", "").strip()
PAYSTACK_PUBLIC_KEY = os.getenv("PAYSTACK_PUBLIC_KEY", "").strip()
PAYSTACK_CALLBACK_URL = os.getenv("PAYSTACK_CALLBACK_URL", "").strip()
APP_NAME = "Cauldra"

allowed_origins_raw = os.getenv("SUPPLY_AI_CORS_ORIGINS", "")
ALLOWED_ORIGINS = [x.strip() for x in allowed_origins_raw.split(",") if x.strip()]

if REFRESH_COOKIE_SAMESITE not in {"lax", "strict", "none"}:
    raise RuntimeError("SUPPLY_AI_REFRESH_COOKIE_SAMESITE must be lax, strict, or none.")
if REFRESH_COOKIE_SAMESITE == "none" and not REFRESH_COOKIE_SECURE:
    raise RuntimeError("SameSite=None refresh cookies require SUPPLY_AI_REFRESH_COOKIE_SECURE=true.")
if IS_PRODUCTION:
    if not REFRESH_COOKIE_SECURE:
        raise RuntimeError("Production requires SUPPLY_AI_REFRESH_COOKIE_SECURE=true.")
    if not TRUSTED_HOSTS or "*" in TRUSTED_HOSTS:
        raise RuntimeError("Production requires explicit SUPPLY_AI_TRUSTED_HOSTS; do not use *.")
    if "*" in ALLOWED_ORIGINS:
        raise RuntimeError("SUPPLY_AI_CORS_ORIGINS must list exact origins in production.")
elif not TRUSTED_HOSTS:
    TRUSTED_HOSTS = ["127.0.0.1", "localhost", "testserver"]

app = FastAPI(
    title="Cauldra Backend",
    version="4.1",
    docs_url=None if IS_PRODUCTION else "/docs",
    redoc_url=None if IS_PRODUCTION else "/redoc",
    openapi_url=None if IS_PRODUCTION else "/openapi.json",
)
app.add_middleware(TrustedHostMiddleware, allowed_hosts=TRUSTED_HOSTS)
if ALLOWED_ORIGINS:
    app.add_middleware(
        CORSMiddleware,
        allow_origins=ALLOWED_ORIGINS,
        allow_credentials=True,
        allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
        allow_headers=["Authorization", "Content-Type", "Accept"],
    )

class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        response = await call_next(request)
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("X-Frame-Options", "DENY")
        response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
        response.headers.setdefault("Permissions-Policy", "camera=(self), microphone=(), geolocation=()")
        response.headers.setdefault(
            "Content-Security-Policy",
            "default-src 'self'; base-uri 'self'; frame-ancestors 'none'; form-action 'self'; "
            "img-src 'self' data: blob: https://flagcdn.com; media-src 'self' blob:; worker-src 'self' blob:; connect-src 'self'; "
            "style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; font-src 'self' data:"
        )
        if IS_PRODUCTION:
            response.headers.setdefault("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
        return response

app.add_middleware(SecurityHeadersMiddleware)
if ASSETS_DIR.is_dir():
    app.mount("/assets", StaticFiles(directory=str(ASSETS_DIR)), name="assets")

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False},
    pool_pre_ping=True,
)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

@event.listens_for(engine, "connect")
def set_sqlite_pragma(dbapi_connection, connection_record):
    cursor = dbapi_connection.cursor()
    cursor.execute("PRAGMA foreign_keys=ON")
    cursor.close()

# -----------------------------------------------------------------------------
# MODELS
# -----------------------------------------------------------------------------
class BusinessProfile(Base):
    __tablename__ = "business_profile"
    id = Column(Integer, primary_key=True, index=True)
    business_code = Column(String, unique=True, index=True, nullable=False)
    company_name = Column(String, default="Cauldra")
    email = Column(String, nullable=True)
    phone = Column(String, nullable=True)
    address = Column(String, nullable=True)
    currency = Column(String, default="USD ($)")
    tax_id = Column(String, nullable=True)
    country = Column(String, nullable=True)
    country_code = Column(String, nullable=True)
    locale = Column(String, default="en-US")
    language = Column(String, default="en")
    timezone = Column(String, default="UTC")
    phone_country_code = Column(String, nullable=True)
    subscription_plan = Column(String, nullable=False, default="starter")
    billing_interval = Column(String, nullable=False, default="monthly")
    subscription_started_at = Column(SQLDateTime, default=datetime.utcnow, nullable=False)
    trial_started_at = Column(SQLDateTime, default=datetime.utcnow, nullable=False)

    users = relationship("User", back_populates="business_rel", cascade="all, delete-orphan")

class Warehouse(Base):
    __tablename__ = "warehouses"
    __table_args__ = (UniqueConstraint("business_id", "name", name="uq_warehouse_business_name"),)
    id = Column(Integer, primary_key=True, index=True)
    business_id = Column(Integer, ForeignKey("business_profile.id", ondelete="CASCADE"), nullable=False, index=True)
    name = Column(String, nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
    created_at = Column(SQLDateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(SQLDateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, index=True, nullable=False)
    password = Column(String, nullable=False)
    previous_password_hash = Column(String, nullable=True)
    role = Column(String, nullable=False, default="staff")
    firstname = Column(String, nullable=True)
    lastname = Column(String, nullable=True)
    position = Column(String, nullable=True)
    email = Column(String, nullable=False)
    phone = Column(String, nullable=False)
    business_id = Column(Integer, ForeignKey("business_profile.id", ondelete="CASCADE"), nullable=False)
    must_change_password = Column(Boolean, default=False, nullable=False)
    disabled = Column(Boolean, default=False, nullable=False)
    auth_version = Column(Integer, default=1, nullable=False)

    business_rel = relationship("BusinessProfile", back_populates="users")
    # No ownership cascade: business data survives user deletion.

class Product(Base):
    __tablename__ = "products"
    id = Column(Integer, primary_key=True, index=True)
    sku = Column(String, index=True, nullable=False)
    barcode = Column(String, index=True, nullable=True)
    name = Column(String, nullable=False)
    category = Column(String, nullable=False)
    size = Column(String, nullable=True)
    quantity = Column(Integer, nullable=False, default=0)
    min_stock_level = Column(Integer, nullable=False, default=5)
    cost_price = Column(Float, nullable=False, default=0.0)
    wholesale_price = Column(Float, default=0.0)
    retail_price = Column(Float, nullable=False, default=0.0)
    warehouse = Column(String, default="Main Central Warehouse")
    initial_stock = Column(Integer, default=0)
    created_at = Column(SQLDateTime, default=datetime.utcnow, nullable=False)
    expiry_date = Column(SQLDateTime, nullable=True)
    business_id = Column(Integer, ForeignKey("business_profile.id", ondelete="CASCADE"), nullable=False)
    owner_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True)

class Supplier(Base):
    __tablename__ = "suppliers"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    contact_email = Column(String, nullable=True)
    phone = Column(String, nullable=False)
    lead_time_days = Column(Integer, default=3)
    business_id = Column(Integer, ForeignKey("business_profile.id", ondelete="CASCADE"), nullable=False)
    owner_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True)

class PurchaseOrder(Base):
    __tablename__ = "purchase_orders"
    id = Column(Integer, primary_key=True, index=True)
    supplier_id = Column(Integer, ForeignKey("suppliers.id", ondelete="SET NULL"), nullable=True)
    status = Column(String, default="DRAFT")
    total_estimated_cost = Column(Float, default=0.0)
    email_draft = Column(Text)
    business_id = Column(Integer, ForeignKey("business_profile.id", ondelete="CASCADE"), nullable=False)
    owner_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    created_at = Column(SQLDateTime, default=datetime.utcnow, nullable=False)

class WarehouseStock(Base):
    __tablename__ = "warehouse_stocks"
    id = Column(Integer, primary_key=True, index=True)
    business_id = Column(Integer, ForeignKey("business_profile.id", ondelete="CASCADE"), nullable=False, index=True)
    product_id = Column(Integer, ForeignKey("products.id", ondelete="CASCADE"), nullable=False, index=True)
    warehouse = Column(String, nullable=False)
    quantity = Column(Integer, nullable=False, default=0)
    created_at = Column(SQLDateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(SQLDateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

class ProductDeletionRequest(Base):
    __tablename__ = "product_deletion_requests"
    id = Column(Integer, primary_key=True, index=True)
    business_id = Column(Integer, ForeignKey("business_profile.id", ondelete="CASCADE"), nullable=False, index=True)
    product_id = Column(Integer, ForeignKey("products.id", ondelete="SET NULL"), nullable=True)
    product_name = Column(String, nullable=False)
    requested_by_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    requested_by_name = Column(String, nullable=False)
    status = Column(String, nullable=False, default="PENDING", index=True)
    reason = Column(Text, nullable=True)
    resolved_by_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    resolved_by_name = Column(String, nullable=True)
    created_at = Column(SQLDateTime, default=datetime.utcnow, nullable=False)
    resolved_at = Column(SQLDateTime, nullable=True)

class SaleModel(Base):
    __tablename__ = "sales"
    id = Column(Integer, primary_key=True, index=True)
    business_id = Column(Integer, ForeignKey("business_profile.id", ondelete="CASCADE"), nullable=False)
    product_id = Column(Integer, ForeignKey("products.id", ondelete="SET NULL"), nullable=True)
    quantity = Column(Integer, default=0)
    total_price = Column(Float, default=0.0)
    timestamp = Column(SQLDateTime, default=datetime.utcnow, nullable=False)

class BusinessDay(Base):
    __tablename__ = "business_days"
    id = Column(Integer, primary_key=True, index=True)
    business_id = Column(Integer, ForeignKey("business_profile.id", ondelete="CASCADE"), nullable=False, index=True)
    date = Column(String, nullable=False, index=True)
    opened_at = Column(SQLDateTime, default=datetime.utcnow, nullable=False)
    closed_at = Column(SQLDateTime, nullable=True)
    is_open = Column(Boolean, default=True, nullable=False)

class Alert(Base):
    __tablename__ = "alerts"
    id = Column(Integer, primary_key=True, index=True)
    business_id = Column(Integer, ForeignKey("business_profile.id", ondelete="CASCADE"), nullable=False, index=True)
    type = Column(String, nullable=False)
    title = Column(String, nullable=False)
    message = Column(Text, nullable=False)
    severity = Column(String, default="info")
    created_at = Column(SQLDateTime, default=datetime.utcnow, nullable=False)
    expires_at = Column(SQLDateTime, nullable=True)

class AlertRead(Base):
    __tablename__ = "alert_reads"
    id = Column(Integer, primary_key=True, index=True)
    alert_id = Column(Integer, ForeignKey("alerts.id", ondelete="CASCADE"), nullable=False)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    read_at = Column(SQLDateTime, default=datetime.utcnow, nullable=False)

class AuditLog(Base):
    __tablename__ = "audit_logs"
    id = Column(Integer, primary_key=True, index=True)
    business_id = Column(Integer, ForeignKey("business_profile.id", ondelete="CASCADE"), nullable=False, index=True)
    actor_user_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    actor_username = Column(String, nullable=True)
    actor_role = Column(String, nullable=True)
    action = Column(String, nullable=False)
    target_user_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    target_username = Column(String, nullable=True)
    description = Column(Text, nullable=False)
    created_at = Column(SQLDateTime, default=datetime.utcnow, nullable=False)

class AccountActionRequest(Base):
    __tablename__ = "account_action_requests"
    id = Column(Integer, primary_key=True, index=True)
    business_id = Column(Integer, ForeignKey("business_profile.id", ondelete="CASCADE"), nullable=False, index=True)
    target_user_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    target_username = Column(String, nullable=False)
    action = Column(String, nullable=False)  # delete / disable
    requested_by_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    requested_by_name = Column(String, nullable=True)
    status = Column(String, default="PENDING", nullable=False, index=True)
    resolved_by_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    resolved_at = Column(SQLDateTime, nullable=True)
    created_at = Column(SQLDateTime, default=datetime.utcnow, nullable=False)

class SessionRevocation(Base):
    __tablename__ = "session_revocations"
    id = Column(Integer, primary_key=True, index=True)
    jti = Column(String, unique=True, index=True, nullable=False)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=True)
    expires_at = Column(SQLDateTime, nullable=False)
    revoked_at = Column(SQLDateTime, default=datetime.utcnow, nullable=False)

class RefreshSession(Base):
    __tablename__ = "refresh_sessions"
    id = Column(Integer, primary_key=True, index=True)
    token_hash = Column(String, unique=True, index=True, nullable=False)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    business_id = Column(Integer, ForeignKey("business_profile.id", ondelete="CASCADE"), nullable=False, index=True)
    expires_at = Column(SQLDateTime, nullable=False)
    revoked_at = Column(SQLDateTime, nullable=True)
    created_at = Column(SQLDateTime, default=datetime.utcnow, nullable=False)
    replaced_by_hash = Column(String, nullable=True)

class AuthFailure(Base):
    __tablename__ = "auth_failures"
    id = Column(Integer, primary_key=True, index=True)
    scope = Column(String, index=True, nullable=False)
    key_hash = Column(String, index=True, nullable=False)
    failures = Column(Integer, default=0, nullable=False)
    window_started_at = Column(SQLDateTime, default=datetime.utcnow, nullable=False)
    locked_until = Column(SQLDateTime, nullable=True)

class PasswordRecovery(Base):
    __tablename__ = "password_recoveries"
    id = Column(Integer, primary_key=True, index=True)
    recovery_id = Column(String, unique=True, index=True, nullable=False)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    channel = Column(String, nullable=False)
    code_hash = Column(String, nullable=False)
    expires_at = Column(SQLDateTime, nullable=False)
    resend_after = Column(SQLDateTime, nullable=False)
    attempts = Column(Integer, default=0, nullable=False)
    used = Column(Boolean, default=False, nullable=False)
    created_at = Column(SQLDateTime, default=datetime.utcnow, nullable=False)

class PresenceSession(Base):
    __tablename__ = "presence_sessions"
    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(String, unique=True, index=True, nullable=False)
    business_id = Column(Integer, ForeignKey("business_profile.id", ondelete="CASCADE"), nullable=False)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    signed_in_at = Column(SQLDateTime, default=datetime.utcnow, nullable=False)
    last_seen_at = Column(SQLDateTime, default=datetime.utcnow, nullable=False)
    signed_out_at = Column(SQLDateTime, nullable=True)

class PriceMonitorSource(Base):
    __tablename__ = "price_monitor_sources"
    id = Column(Integer, primary_key=True, index=True)
    business_id = Column(Integer, ForeignKey("business_profile.id", ondelete="CASCADE"), nullable=False)
    supplier_id = Column(Integer, ForeignKey("suppliers.id", ondelete="SET NULL"), nullable=True)
    product_id = Column(Integer, ForeignKey("products.id", ondelete="SET NULL"), nullable=True)
    source_type = Column(String, nullable=False)
    source_url = Column(String, nullable=True)
    last_price = Column(Float, nullable=True)
    last_checked_at = Column(SQLDateTime, nullable=True)
    created_at = Column(SQLDateTime, default=datetime.utcnow, nullable=False)

class PriceHistory(Base):
    __tablename__ = "price_history"
    id = Column(Integer, primary_key=True, index=True)
    source_id = Column(Integer, ForeignKey("price_monitor_sources.id", ondelete="CASCADE"), nullable=False)
    price = Column(Float, nullable=False)
    recorded_at = Column(SQLDateTime, default=datetime.utcnow, nullable=False)

class GeneralCatalog(Base):
    __tablename__ = "general_catalog"
    id = Column(Integer, primary_key=True, index=True)
    barcode = Column(String, unique=True, nullable=True, index=True)
    catalog_key = Column(String, unique=True, index=True, nullable=False, default="legacy")
    product_name = Column(String, nullable=False)
    category = Column(String, nullable=False, default="General")
    brand = Column(String, nullable=True)
    created_at = Column(SQLDateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(SQLDateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

class StoredUpload(Base):
    """Metadata for a private, backend-retained document.

    The file bytes are intentionally stored outside the web root; access is
    always mediated by an authenticated, business-scoped endpoint.
    """
    __tablename__ = "stored_uploads"
    id = Column(Integer, primary_key=True, index=True)
    business_id = Column(Integer, ForeignKey("business_profile.id", ondelete="CASCADE"), nullable=False, index=True)
    uploaded_by_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True)
    kind = Column(String, nullable=False, index=True)
    original_name = Column(String, nullable=False)
    storage_key = Column(String, unique=True, nullable=False, index=True)
    content_type = Column(String, nullable=False)
    size_bytes = Column(Integer, nullable=False)
    content_hash = Column(String, nullable=False, index=True)
    created_at = Column(SQLDateTime, default=datetime.utcnow, nullable=False)

class AIUsageLedger(Base):
    """Immutable, provider-independent record of billable AI activity."""
    __tablename__ = "ai_usage_ledger"
    id = Column(Integer, primary_key=True, index=True)
    business_id = Column(Integer, ForeignKey("business_profile.id", ondelete="CASCADE"), nullable=False, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True)
    operation_type = Column(String, nullable=False, index=True)
    credits_consumed = Column(Integer, nullable=False, default=0)
    billing_period = Column(String, nullable=False, index=True)
    provider = Column(String, nullable=True)
    model = Column(String, nullable=True)
    success = Column(Boolean, nullable=False, default=False)
    input_tokens = Column(Integer, nullable=True)
    output_tokens = Column(Integer, nullable=True)
    estimated_provider_cost = Column(Float, nullable=True)
    created_at = Column(SQLDateTime, default=datetime.utcnow, nullable=False)

class BusinessSubscription(Base):
    __tablename__ = "business_subscriptions"
    id = Column(Integer, primary_key=True, index=True)
    business_id = Column(Integer, ForeignKey("business_profile.id", ondelete="CASCADE"), nullable=False, unique=True, index=True)
    plan = Column(String, nullable=False)
    billing_interval = Column(String, nullable=False)
    status = Column(String, nullable=False, default="trialing", index=True)
    trial_start_at = Column(SQLDateTime, nullable=True)
    trial_end_at = Column(SQLDateTime, nullable=True)
    paid_at = Column(SQLDateTime, nullable=True)
    current_period_start = Column(SQLDateTime, nullable=True)
    current_period_end = Column(SQLDateTime, nullable=True)
    next_billing_at = Column(SQLDateTime, nullable=True)
    paystack_customer_code = Column(String, nullable=True)
    paystack_subscription_code = Column(String, nullable=True)
    paystack_plan_code = Column(String, nullable=True)
    latest_transaction_reference = Column(String, nullable=True)
    payment_status = Column(String, nullable=True)
    cancelled_at = Column(SQLDateTime, nullable=True)
    created_at = Column(SQLDateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(SQLDateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

class PaymentRecord(Base):
    __tablename__ = "payment_records"
    id = Column(Integer, primary_key=True, index=True)
    business_id = Column(Integer, ForeignKey("business_profile.id", ondelete="CASCADE"), nullable=False, index=True)
    subscription_id = Column(Integer, ForeignKey("business_subscriptions.id", ondelete="SET NULL"), nullable=True, index=True)
    plan = Column(String, nullable=False)
    billing_interval = Column(String, nullable=False)
    amount_kobo = Column(Integer, nullable=False)
    currency = Column(String, nullable=False, default="NGN")
    paystack_reference = Column(String, nullable=False, unique=True, index=True)
    status = Column(String, nullable=False, default="initialized", index=True)
    transaction_metadata = Column(Text, nullable=True)
    paid_at = Column(SQLDateTime, nullable=True)
    created_at = Column(SQLDateTime, default=datetime.utcnow, nullable=False)

class PaystackWebhookEvent(Base):
    __tablename__ = "paystack_webhook_events"
    id = Column(Integer, primary_key=True, index=True)
    event_key = Column(String, nullable=False, unique=True, index=True)
    event_type = Column(String, nullable=False)
    received_at = Column(SQLDateTime, default=datetime.utcnow, nullable=False)

Base.metadata.create_all(bind=engine)
UPLOAD_STORAGE_DIR.mkdir(parents=True, exist_ok=True)

# -----------------------------------------------------------------------------
# SAFE MIGRATIONS FOR EXISTING SQLITE DATABASES
# -----------------------------------------------------------------------------
def table_columns(table_name: str) -> set[str]:
    with engine.connect() as conn:
        rows = conn.exec_driver_sql(f"PRAGMA table_info({table_name})").fetchall()
        return {row[1] for row in rows}

def add_column_if_missing(table_name: str, col: str, sql_type: str, default_sql: Optional[str] = None):
    cols = table_columns(table_name)
    if col in cols:
        return
    sql = f"ALTER TABLE {table_name} ADD COLUMN {col} {sql_type}"
    if default_sql is not None:
        sql += f" DEFAULT {default_sql}"
    with engine.begin() as conn:
        conn.exec_driver_sql(sql)

for args in [
    ("business_profile", "country", "TEXT", None),
    ("business_profile", "country_code", "TEXT", None),
    ("business_profile", "locale", "TEXT", "'en-US'"),
    ("business_profile", "language", "TEXT", "'en'"),
    ("business_profile", "timezone", "TEXT", "'UTC'"),
    ("business_profile", "phone_country_code", "TEXT", None),
    ("business_profile", "subscription_plan", "TEXT", "'starter'"),
    ("business_profile", "billing_interval", "TEXT", "'monthly'"),
    ("business_profile", "subscription_started_at", "DATETIME", None),
    ("business_profile", "trial_started_at", "DATETIME", None),
    ("users", "previous_password_hash", "TEXT", None),
    ("users", "disabled", "INTEGER", "0"),
    ("users", "auth_version", "INTEGER", "1"),
    ("products", "barcode", "TEXT", None),
    ("general_catalog", "catalog_key", "TEXT", None),
    ("products", "expiry_date", "DATETIME", None),
    ("purchase_orders", "created_at", "DATETIME", None),
]:
    add_column_if_missing(*args)

# Existing businesses receive an organization-level Starter subscription and
# trial anchor once; creating users never changes either date.
with engine.begin() as conn:
    conn.exec_driver_sql("UPDATE business_profile SET subscription_started_at = COALESCE(subscription_started_at, CURRENT_TIMESTAMP)")
    conn.exec_driver_sql("UPDATE business_profile SET trial_started_at = COALESCE(trial_started_at, subscription_started_at, CURRENT_TIMESTAMP)")
    conn.exec_driver_sql("UPDATE purchase_orders SET created_at = COALESCE(created_at, CURRENT_TIMESTAMP)")

# Central subscription and AI-cost policy.  None represents an intentionally
# unlimited Enterprise people/location resource, not a large hidden cap.
PLAN_CONFIG = {
    "starter": {"label": "Starter", "monthly_price": 20000, "annual_price": 200000, "trial_days": 14,
        "admin": 1, "manager": 1, "staff": 2, "branch": 1, "city": 1, "country": 1, "product": 500, "supplier": 20, "warehouse": 2,
        "purchase_order": 30, "price_monitor": 5, "storage_gb": 5, "included_ai_credits": 500, "ai_overage_unit": 250, "ai_overage_price": 5000},
    "business": {"label": "Business", "monthly_price": 50000, "annual_price": 500000, "trial_days": 14,
        "admin": 2, "manager": 5, "staff": 15, "branch": 5, "city": 5, "country": 2, "product": 2500, "supplier": 100, "warehouse": 10,
        "purchase_order": 200, "price_monitor": 30, "storage_gb": 25, "included_ai_credits": 2500, "ai_overage_unit": 500, "ai_overage_price": 7500},
    "enterprise": {"label": "Enterprise", "monthly_price": 200000, "annual_price": 2100000, "trial_days": 14,
        "admin": None, "manager": None, "staff": None, "branch": None, "city": None, "country": None, "product": 50000, "supplier": 2000, "warehouse": 100,
        "purchase_order": 5000, "price_monitor": 500, "storage_gb": 250, "included_ai_credits": 15000, "ai_overage_unit": 1000, "ai_overage_price": 10000},
}
for _plan_id, _plan in PLAN_CONFIG.items():
    _plan["paystack_monthly_plan_code"] = os.getenv(f"PAYSTACK_{_plan_id.upper()}_MONTHLY_PLAN_CODE", "").strip()
    _plan["paystack_annual_plan_code"] = os.getenv(f"PAYSTACK_{_plan_id.upper()}_ANNUAL_PLAN_CODE", "").strip()
AI_CREDIT_WEIGHTS = {"margin_advisor": 2, "chat": 2, "inventory_insight": 5, "predictive_analysis": 8, "invoice_ocr": 10, "complex_analysis": 10}
UPGRADE_PATH = {"starter": "Business", "business": "Enterprise", "enterprise": "Enterprise"}

def get_or_create_subscription(db: Session, business: BusinessProfile) -> BusinessSubscription:
    """BusinessSubscription is the single source of truth for plan/trial/billing state.
    This backfills a row for any business that predates the subscription table (or
    the rare race where a request lands before registration's own insert commits),
    seeded from the legacy BusinessProfile columns so no existing business is locked out."""
    sub = db.query(BusinessSubscription).filter(BusinessSubscription.business_id == business.id).first()
    if sub:
        return sub
    now = datetime.utcnow()
    plan = (business.subscription_plan or "starter").strip().lower()
    if plan not in PLAN_CONFIG:
        plan = "starter"
    interval = (business.billing_interval or "monthly").strip().lower()
    if interval not in ("monthly", "annual"):
        interval = "monthly"
    trial_start = business.trial_started_at or business.subscription_started_at or now
    trial_end = trial_start + timedelta(days=PLAN_CONFIG[plan]["trial_days"])
    sub = BusinessSubscription(
        business_id=business.id, plan=plan, billing_interval=interval,
        status="trialing" if now < trial_end else "expired",
        trial_start_at=trial_start, trial_end_at=trial_end,
        current_period_start=trial_start, current_period_end=trial_end,
    )
    db.add(sub); db.commit(); db.refresh(sub)
    return sub

def subscription_for(db: Session, business: BusinessProfile) -> dict:
    sub = get_or_create_subscription(db, business)
    return PLAN_CONFIG.get((sub.plan or "starter").strip().lower(), PLAN_CONFIG["starter"])

def add_billing_interval(start: datetime, interval: str) -> datetime:
    months = 12 if interval == "annual" else 1
    month = start.month + months
    return datetime(start.year + (month - 1) // 12, (month - 1) % 12 + 1, 1)

def get_subscription(db: Session, business_id: int) -> Optional[BusinessSubscription]:
    return db.query(BusinessSubscription).filter(BusinessSubscription.business_id == business_id).first()

def refresh_subscription_status(db: Session, subscription: Optional[BusinessSubscription]) -> Optional[BusinessSubscription]:
    if not subscription:
        return None
    now = datetime.utcnow()
    if subscription.status == "trialing" and subscription.trial_end_at and now >= subscription.trial_end_at:
        subscription.status = "expired"; subscription.payment_status = "unpaid"; db.commit()
    elif subscription.status == "active" and subscription.current_period_end and now >= subscription.current_period_end:
        subscription.status = "past_due"; db.commit()
    return subscription

def require_subscription_access(db: Session, user: User):
    business = db.query(BusinessProfile).filter(BusinessProfile.id == user.business_id).first()
    subscription = refresh_subscription_status(db, get_or_create_subscription(db, business))
    if subscription.status not in {"trialing", "active"}:
        raise HTTPException(status_code=402, detail="Your 14-day trial has ended. Subscribe to continue using Cauldra." if subscription.status == "expired" else "Your subscription is not currently active. Choose a plan or subscribe to continue.")
    return subscription

def billing_period_for(db: Session, business: BusinessProfile, now: Optional[datetime] = None) -> tuple[datetime, datetime, str]:
    sub = get_or_create_subscription(db, business)
    now = now or datetime.utcnow()
    start = sub.current_period_start or sub.trial_start_at or now
    annual = (sub.billing_interval or "monthly").lower() == "annual"
    months = 12 if annual else 1
    elapsed_months = max(0, (now.year - start.year) * 12 + now.month - start.month)
    period_index = elapsed_months // months
    period_start_month = start.month + period_index * months
    period_start = datetime(start.year + (period_start_month - 1) // 12, (period_start_month - 1) % 12 + 1, 1)
    next_month = period_start.month + months
    period_end = datetime(period_start.year + (next_month - 1) // 12, (next_month - 1) % 12 + 1, 1)
    return period_start, period_end, period_start.strftime("%Y-%m-%d")

def raise_limit_reached(db: Session, business: BusinessProfile, resource: str, current: int, maximum: int):
    plan = subscription_for(db, business)
    upgrade = UPGRADE_PATH.get((get_or_create_subscription(db, business).plan or "starter").lower(), "Enterprise")
    raise HTTPException(status_code=409, detail=f"You have reached the {plan['label']} {resource} limit of {maximum}. Current usage: {current}/{maximum}. Upgrade to {upgrade} for a higher allowance.")

def check_plan_limit(db: Session, business: BusinessProfile, resource: str, current: int, increment: int = 1):
    maximum = subscription_for(db, business).get(resource)
    if maximum is not None and current + increment > maximum:
        raise_limit_reached(db, business, resource.replace("_", " "), current, maximum)

def check_storage_limit(db: Session, business: BusinessProfile, byte_count: int):
    maximum = subscription_for(db, business)["storage_gb"] * 1024 * 1024 * 1024
    current = db.query(func.coalesce(func.sum(StoredUpload.size_bytes), 0)).filter(StoredUpload.business_id == business.id).scalar() or 0
    if current + byte_count > maximum:
        raise_limit_reached(db, business, "storage", round(current / (1024**3), 2), subscription_for(db, business)["storage_gb"])

def record_ai_usage(db: Session, user: User, operation_type: str, success: bool, provider: str, model: str, **metadata):
    business = db.query(BusinessProfile).filter(BusinessProfile.id == user.business_id).first()
    _, _, period = billing_period_for(db, business)
    credits = AI_CREDIT_WEIGHTS[operation_type] if success else 0
    db.add(AIUsageLedger(business_id=user.business_id, user_id=user.id, operation_type=operation_type, credits_consumed=credits,
                         billing_period=period, provider=provider, model=model, success=success,
                         input_tokens=metadata.get("input_tokens"), output_tokens=metadata.get("output_tokens"), estimated_provider_cost=metadata.get("estimated_provider_cost")))
    return credits

def usage_summary(db: Session, business: BusinessProfile) -> dict:
    sub = get_or_create_subscription(db, business)
    plan = subscription_for(db, business); period_start, period_end, period = billing_period_for(db, business)
    used = db.query(func.coalesce(func.sum(AIUsageLedger.credits_consumed), 0)).filter(AIUsageLedger.business_id == business.id, AIUsageLedger.billing_period == period, AIUsageLedger.success == True).scalar() or 0
    included = plan["included_ai_credits"]; overage = max(0, int(used) - included)
    overage_charge = ((overage + plan["ai_overage_unit"] - 1) // plan["ai_overage_unit"]) * plan["ai_overage_price"] if overage else 0
    trial_end = sub.trial_end_at or (datetime.utcnow() + timedelta(days=plan["trial_days"]))
    return {"plan": (sub.plan or "starter").lower(), "plan_label": plan["label"], "billing_interval": sub.billing_interval or "monthly",
            "status": sub.status, "billing_period_start": period_start.isoformat(), "billing_period_end": period_end.isoformat(),
            "trial_active": sub.status == "trialing", "trial_ends_at": trial_end.isoformat(),
            "trial_days_remaining": max(0, (trial_end - datetime.utcnow()).days) if sub.status == "trialing" else 0,
            "included_ai_credits": included, "used_ai_credits": int(used), "remaining_ai_credits": max(0, included-int(used)),
            "overage_credits": overage, "estimated_overage_charge": overage_charge, "ai_warning": "overage" if overage else ("warning" if used >= included * .8 else None)}

def backfill_business_subscriptions():
    db = SessionLocal()
    try:
        for business in db.query(BusinessProfile).all():
            get_or_create_subscription(db, business)
    finally:
        db.close()

backfill_business_subscriptions()

# Migrate old role naming.
def migrate_legacy_roles():
    db = SessionLocal()
    try:
        db.query(User).filter(User.role == "owner").update({User.role: "admin"}, synchronize_session=False)
        db.commit()
    finally:
        db.close()

migrate_legacy_roles()

def seed_warehouse_registry():
    """Backfill the authoritative warehouse registry from existing product/stock rows."""
    db = SessionLocal()
    try:
        business_ids = {bid for (bid,) in db.query(Product.business_id).distinct().all() if bid is not None}
        business_ids.update({bid for (bid,) in db.query(WarehouseStock.business_id).distinct().all() if bid is not None})
        for business_id in business_ids:
            names = set()
            for (name,) in db.query(Product.warehouse).filter(Product.business_id == business_id).distinct().all():
                if name and str(name).strip():
                    names.add(str(name).strip())
            for (name,) in db.query(WarehouseStock.warehouse).filter(WarehouseStock.business_id == business_id).distinct().all():
                if name and str(name).strip():
                    names.add(str(name).strip())
            if not names:
                names.add("Main Central Warehouse")
            existing = {w.name.casefold(): w for w in db.query(Warehouse).filter(Warehouse.business_id == business_id).all()}
            for name in sorted(names):
                if name.casefold() not in existing:
                    db.add(Warehouse(business_id=business_id, name=name, is_active=True))
        db.commit()
    finally:
        db.close()

seed_warehouse_registry()

# -----------------------------------------------------------------------------
# CANONICAL COUNTRY CONTEXT
# -----------------------------------------------------------------------------
# Registration and Business Profile country settings are authoritative for the
# entire business. Currency, phone code, and country identity are normalized
# server-side so the client cannot accidentally save a mismatched combination.
COUNTRY_CONTEXTS = {
    'AF': {"name": 'Afghanistan', "code": '+93', "currency": 'AFN (؋)', "timezone": 'Asia/Kabul'},
    'AL': {"name": 'Albania', "code": '+355', "currency": 'ALL (ALL)', "timezone": 'Europe/Tirane'},
    'DZ': {"name": 'Algeria', "code": '+213', "currency": 'DZD (DZD)', "timezone": 'Africa/Algiers'},
    'AS': {"name": 'American Samoa', "code": '+1684', "currency": 'USD ($)', "timezone": 'Pacific/Pago_Pago'},
    'AD': {"name": 'Andorra', "code": '+376', "currency": 'EUR (€)', "timezone": 'Europe/Andorra'},
    'AO': {"name": 'Angola', "code": '+244', "currency": 'AOA (Kz)', "timezone": 'Africa/Luanda'},
    'AI': {"name": 'Anguilla', "code": '+1264', "currency": 'XCD ($)', "timezone": 'America/Anguilla'},
    'AG': {"name": 'Antigua and Barbuda', "code": '+1268', "currency": 'XCD ($)', "timezone": 'America/Antigua'},
    'AR': {"name": 'Argentina', "code": '+54', "currency": 'ARS ($)', "timezone": 'America/Argentina/Buenos_Aires'},
    'AM': {"name": 'Armenia', "code": '+374', "currency": 'AMD (֏)', "timezone": 'Asia/Yerevan'},
    'AW': {"name": 'Aruba', "code": '+297', "currency": 'AWG (AWG)', "timezone": 'America/Aruba'},
    'AU': {"name": 'Australia', "code": '+61', "currency": 'AUD ($)', "timezone": 'Australia/Sydney'},
    'AT': {"name": 'Austria', "code": '+43', "currency": 'EUR (€)', "timezone": 'Europe/Vienna'},
    'AZ': {"name": 'Azerbaijan', "code": '+994', "currency": 'AZN (₼)', "timezone": 'Asia/Baku'},
    'BH': {"name": 'Bahrain', "code": '+973', "currency": 'BHD (BHD)', "timezone": 'Asia/Bahrain'},
    'BD': {"name": 'Bangladesh', "code": '+880', "currency": 'BDT (৳)', "timezone": 'Asia/Dhaka'},
    'BB': {"name": 'Barbados', "code": '+1246', "currency": 'BBD ($)', "timezone": 'America/Barbados'},
    'BY': {"name": 'Belarus', "code": '+375', "currency": 'BYN (BYN)', "timezone": 'Europe/Minsk'},
    'BE': {"name": 'Belgium', "code": '+32', "currency": 'EUR (€)', "timezone": 'Europe/Brussels'},
    'BZ': {"name": 'Belize', "code": '+501', "currency": 'BZD ($)', "timezone": 'America/Belize'},
    'BJ': {"name": 'Benin', "code": '+229', "currency": 'XOF (F CFA)', "timezone": 'Africa/Porto-Novo'},
    'BM': {"name": 'Bermuda', "code": '+1441', "currency": 'BMD ($)', "timezone": 'Atlantic/Bermuda'},
    'BT': {"name": 'Bhutan', "code": '+975', "currency": 'INR (₹)', "timezone": 'Asia/Thimphu'},
    'BO': {"name": 'Bolivia', "code": '+591', "currency": 'BOB (Bs)', "timezone": 'America/La_Paz'},
    'BA': {"name": 'Bosnia and Herzegovina', "code": '+387', "currency": 'BAM (KM)', "timezone": 'Europe/Sarajevo'},
    'BW': {"name": 'Botswana', "code": '+267', "currency": 'BWP (P)', "timezone": 'Africa/Gaborone'},
    'BR': {"name": 'Brazil', "code": '+55', "currency": 'BRL (R$)', "timezone": 'America/Sao_Paulo'},
    'IO': {"name": 'British Indian Ocean Territory', "code": '+246', "currency": 'USD ($)', "timezone": 'Indian/Chagos'},
    'BN': {"name": 'Brunei', "code": '+673', "currency": 'BND ($)', "timezone": 'Asia/Brunei'},
    'BG': {"name": 'Bulgaria', "code": '+359', "currency": 'BGN (BGN)', "timezone": 'Europe/Sofia'},
    'BF': {"name": 'Burkina Faso', "code": '+226', "currency": 'XOF (F CFA)', "timezone": 'Africa/Ouagadougou'},
    'BI': {"name": 'Burundi', "code": '+257', "currency": 'BIF (BIF)', "timezone": 'Africa/Bujumbura'},
    'KH': {"name": 'Cambodia', "code": '+855', "currency": 'KHR (៛)', "timezone": 'Asia/Phnom_Penh'},
    'CM': {"name": 'Cameroon', "code": '+237', "currency": 'XAF (FCFA)', "timezone": 'Africa/Douala'},
    'CA': {"name": 'Canada', "code": '+1', "currency": 'CAD ($)', "timezone": 'America/Toronto'},
    'CV': {"name": 'Cape Verde', "code": '+238', "currency": 'CVE (CVE)', "timezone": 'Atlantic/Cape_Verde'},
    'KY': {"name": 'Cayman Islands', "code": '+1345', "currency": 'KYD ($)', "timezone": 'America/Cayman'},
    'CF': {"name": 'Central African Republic', "code": '+236', "currency": 'XAF (FCFA)', "timezone": 'Africa/Bangui'},
    'TD': {"name": 'Chad', "code": '+235', "currency": 'XAF (FCFA)', "timezone": 'Africa/Ndjamena'},
    'CL': {"name": 'Chile', "code": '+56', "currency": 'CLP ($)', "timezone": 'America/Santiago'},
    'CN': {"name": 'China', "code": '+86', "currency": 'CNY (¥)', "timezone": 'Asia/Shanghai'},
    'CX': {"name": 'Christmas Island', "code": '+61', "currency": 'AUD ($)', "timezone": 'Indian/Christmas'},
    'CC': {"name": 'Cocos (Keeling) Islands', "code": '+61', "currency": 'AUD ($)', "timezone": 'Indian/Cocos'},
    'CO': {"name": 'Colombia', "code": '+57', "currency": 'COP ($)', "timezone": 'America/Bogota'},
    'KM': {"name": 'Comoros', "code": '+269', "currency": 'KMF (CF)', "timezone": 'Indian/Comoro'},
    'CK': {"name": 'Cook Islands', "code": '+682', "currency": 'NZD ($)', "timezone": 'Pacific/Rarotonga'},
    'CR': {"name": 'Costa Rica', "code": '+506', "currency": 'CRC (₡)', "timezone": 'America/Costa_Rica'},
    'HR': {"name": 'Croatia', "code": '+385', "currency": 'EUR (€)', "timezone": 'Europe/Zagreb'},
    'CU': {"name": 'Cuba', "code": '+53', "currency": 'CUP ($)', "timezone": 'America/Havana'},
    'CY': {"name": 'Cyprus', "code": '+357', "currency": 'EUR (€)', "timezone": 'Asia/Nicosia'},
    'CZ': {"name": 'Czechia', "code": '+420', "currency": 'CZK (Kč)', "timezone": 'Europe/Prague'},
    'CD': {"name": 'Democratic Republic of the Congo', "code": '+243', "currency": 'CDF (CDF)', "timezone": 'Africa/Kinshasa'},
    'DK': {"name": 'Denmark', "code": '+45', "currency": 'DKK (kr)', "timezone": 'Europe/Copenhagen'},
    'DJ': {"name": 'Djibouti', "code": '+253', "currency": 'DJF (DJF)', "timezone": 'Africa/Djibouti'},
    'DM': {"name": 'Dominica', "code": '+1767', "currency": 'XCD ($)', "timezone": 'America/Dominica'},
    'DO': {"name": 'Dominican Republic', "code": '+1809', "currency": 'DOP ($)', "timezone": 'America/Santo_Domingo'},
    'TL': {"name": 'Timor-Leste', "code": '+670', "currency": 'USD ($)', "timezone": 'Asia/Dili'},
    'EC': {"name": 'Ecuador', "code": '+593', "currency": 'USD ($)', "timezone": 'America/Guayaquil'},
    'EG': {"name": 'Egypt', "code": '+20', "currency": 'EGP (E£)', "timezone": 'Africa/Cairo'},
    'SV': {"name": 'El Salvador', "code": '+503', "currency": 'USD ($)', "timezone": 'America/El_Salvador'},
    'GQ': {"name": 'Equatorial Guinea', "code": '+240', "currency": 'XAF (FCFA)', "timezone": 'Africa/Malabo'},
    'ER': {"name": 'Eritrea', "code": '+291', "currency": 'ERN (ERN)', "timezone": 'Africa/Asmara'},
    'EE': {"name": 'Estonia', "code": '+372', "currency": 'EUR (€)', "timezone": 'Europe/Tallinn'},
    'ET': {"name": 'Ethiopia', "code": '+251', "currency": 'ETB (ETB)', "timezone": 'Africa/Addis_Ababa'},
    'FK': {"name": 'Falkland Islands', "code": '+500', "currency": 'FKP (£)', "timezone": 'Atlantic/Stanley'},
    'FO': {"name": 'Faroe Islands', "code": '+298', "currency": 'DKK (kr)', "timezone": 'Atlantic/Faroe'},
    'FM': {"name": 'Federated States of Micronesia', "code": '+691', "currency": 'USD ($)', "timezone": 'Pacific/Pohnpei'},
    'FJ': {"name": 'Fiji', "code": '+679', "currency": 'FJD ($)', "timezone": 'Pacific/Fiji'},
    'FI': {"name": 'Finland', "code": '+358', "currency": 'EUR (€)', "timezone": 'Europe/Helsinki'},
    'FR': {"name": 'France', "code": '+33', "currency": 'EUR (€)', "timezone": 'Europe/Paris'},
    'GF': {"name": 'French Guiana', "code": '+594', "currency": 'EUR (€)', "timezone": 'America/Cayenne'},
    'PF': {"name": 'French Polynesia', "code": '+689', "currency": 'XPF (CFPF)', "timezone": 'Pacific/Tahiti'},
    'GA': {"name": 'Gabon', "code": '+241', "currency": 'XAF (FCFA)', "timezone": 'Africa/Libreville'},
    'GE': {"name": 'Georgia', "code": '+995', "currency": 'GEL (₾)', "timezone": 'Asia/Tbilisi'},
    'DE': {"name": 'Germany', "code": '+49', "currency": 'EUR (€)', "timezone": 'Europe/Berlin'},
    'GH': {"name": 'Ghana', "code": '+233', "currency": 'GHS (GH₵)', "timezone": 'Africa/Accra'},
    'GI': {"name": 'Gibraltar', "code": '+350', "currency": 'GIP (£)', "timezone": 'Europe/Gibraltar'},
    'GR': {"name": 'Greece', "code": '+30', "currency": 'EUR (€)', "timezone": 'Europe/Athens'},
    'GL': {"name": 'Greenland', "code": '+299', "currency": 'DKK (kr)', "timezone": 'America/Nuuk'},
    'GD': {"name": 'Grenada', "code": '+1473', "currency": 'XCD ($)', "timezone": 'America/Grenada'},
    'GP': {"name": 'Guadeloupe', "code": '+590', "currency": 'EUR (€)', "timezone": 'America/Guadeloupe'},
    'GU': {"name": 'Guam', "code": '+1671', "currency": 'USD ($)', "timezone": 'Pacific/Guam'},
    'GT': {"name": 'Guatemala', "code": '+502', "currency": 'GTQ (Q)', "timezone": 'America/Guatemala'},
    'GG': {"name": 'Guernsey', "code": '+44', "currency": 'GBP (£)', "timezone": 'Europe/Guernsey'},
    'GN': {"name": 'Guinea', "code": '+224', "currency": 'GNF (FG)', "timezone": 'Africa/Conakry'},
    'GW': {"name": 'Guinea-Bissau', "code": '+245', "currency": 'XOF (F CFA)', "timezone": 'Africa/Bissau'},
    'GY': {"name": 'Guyana', "code": '+592', "currency": 'GYD ($)', "timezone": 'America/Guyana'},
    'HT': {"name": 'Haiti', "code": '+509', "currency": 'HTG (HTG)', "timezone": 'America/Port-au-Prince'},
    'HN': {"name": 'Honduras', "code": '+504', "currency": 'HNL (L)', "timezone": 'America/Tegucigalpa'},
    'HK': {"name": 'Hong Kong', "code": '+852', "currency": 'HKD ($)', "timezone": 'Asia/Hong_Kong'},
    'HU': {"name": 'Hungary', "code": '+36', "currency": 'HUF (Ft)', "timezone": 'Europe/Budapest'},
    'IS': {"name": 'Iceland', "code": '+354', "currency": 'ISK (kr)', "timezone": 'Atlantic/Reykjavik'},
    'IN': {"name": 'India', "code": '+91', "currency": 'INR (₹)', "timezone": 'Asia/Kolkata'},
    'ID': {"name": 'Indonesia', "code": '+62', "currency": 'IDR (Rp)', "timezone": 'Asia/Jakarta'},
    'IR': {"name": 'Iran', "code": '+98', "currency": 'IRR (IRR)', "timezone": 'Asia/Tehran'},
    'IQ': {"name": 'Iraq', "code": '+964', "currency": 'IQD (IQD)', "timezone": 'Asia/Baghdad'},
    'IE': {"name": 'Ireland', "code": '+353', "currency": 'EUR (€)', "timezone": 'Europe/Dublin'},
    'IM': {"name": 'Isle of Man', "code": '+44', "currency": 'GBP (£)', "timezone": 'Europe/Isle_of_Man'},
    'IL': {"name": 'Israel', "code": '+972', "currency": 'ILS (₪)', "timezone": 'Asia/Jerusalem'},
    'IT': {"name": 'Italy', "code": '+39', "currency": 'EUR (€)', "timezone": 'Europe/Rome'},
    'CI': {"name": 'Côte d’Ivoire', "code": '+225', "currency": 'XOF (F CFA)', "timezone": 'Africa/Abidjan'},
    'JM': {"name": 'Jamaica', "code": '+1876', "currency": 'JMD ($)', "timezone": 'America/Jamaica'},
    'JP': {"name": 'Japan', "code": '+81', "currency": 'JPY (¥)', "timezone": 'Asia/Tokyo'},
    'JE': {"name": 'Jersey', "code": '+44', "currency": 'GBP (£)', "timezone": 'Europe/Jersey'},
    'JO': {"name": 'Jordan', "code": '+962', "currency": 'JOD (JOD)', "timezone": 'Asia/Amman'},
    'KZ': {"name": 'Kazakhstan', "code": '+76', "currency": 'KZT (₸)', "timezone": 'Asia/Almaty'},
    'KE': {"name": 'Kenya', "code": '+254', "currency": 'KES (KES)', "timezone": 'Africa/Nairobi'},
    'KI': {"name": 'Kiribati', "code": '+686', "currency": 'AUD ($)', "timezone": 'Pacific/Tarawa'},
    'XK': {"name": 'Kosovo', "code": '+383', "currency": 'EUR (€)', "timezone": 'Europe/Pristina'},
    'KW': {"name": 'Kuwait', "code": '+965', "currency": 'KWD (KWD)', "timezone": 'Asia/Kuwait'},
    'KG': {"name": 'Kyrgyzstan', "code": '+996', "currency": 'KGS (⃀)', "timezone": 'Asia/Bishkek'},
    'LA': {"name": 'Laos', "code": '+856', "currency": 'LAK (₭)', "timezone": 'Asia/Vientiane'},
    'LV': {"name": 'Latvia', "code": '+371', "currency": 'EUR (€)', "timezone": 'Europe/Riga'},
    'LB': {"name": 'Lebanon', "code": '+961', "currency": 'LBP (L£)', "timezone": 'Asia/Beirut'},
    'LS': {"name": 'Lesotho', "code": '+266', "currency": 'ZAR (R)', "timezone": 'Africa/Maseru'},
    'LR': {"name": 'Liberia', "code": '+231', "currency": 'LRD ($)', "timezone": 'Africa/Monrovia'},
    'LY': {"name": 'Libya', "code": '+218', "currency": 'LYD (LYD)', "timezone": 'Africa/Tripoli'},
    'LI': {"name": 'Liechtenstein', "code": '+423', "currency": 'CHF (CHF)', "timezone": 'Europe/Vaduz'},
    'LT': {"name": 'Lithuania', "code": '+370', "currency": 'EUR (€)', "timezone": 'Europe/Vilnius'},
    'LU': {"name": 'Luxembourg', "code": '+352', "currency": 'EUR (€)', "timezone": 'Europe/Luxembourg'},
    'MO': {"name": 'Macau', "code": '+853', "currency": 'MOP (MOP)', "timezone": 'Asia/Macau'},
    'MG': {"name": 'Madagascar', "code": '+261', "currency": 'MGA (Ar)', "timezone": 'Indian/Antananarivo'},
    'MW': {"name": 'Malawi', "code": '+265', "currency": 'MWK (MWK)', "timezone": 'Africa/Blantyre'},
    'MY': {"name": 'Malaysia', "code": '+60', "currency": 'MYR (RM)', "timezone": 'Asia/Kuala_Lumpur'},
    'MV': {"name": 'Maldives', "code": '+960', "currency": 'MVR (MVR)', "timezone": 'Indian/Maldives'},
    'ML': {"name": 'Mali', "code": '+223', "currency": 'XOF (F CFA)', "timezone": 'Africa/Bamako'},
    'MT': {"name": 'Malta', "code": '+356', "currency": 'EUR (€)', "timezone": 'Europe/Malta'},
    'MH': {"name": 'Marshall Islands', "code": '+692', "currency": 'USD ($)', "timezone": 'Pacific/Majuro'},
    'MQ': {"name": 'Martinique', "code": '+596', "currency": 'EUR (€)', "timezone": 'America/Martinique'},
    'MR': {"name": 'Mauritania', "code": '+222', "currency": 'MRU (MRU)', "timezone": 'Africa/Nouakchott'},
    'MU': {"name": 'Mauritius', "code": '+230', "currency": 'MUR (Rs)', "timezone": 'Indian/Mauritius'},
    'YT': {"name": 'Mayotte', "code": '+262', "currency": 'EUR (€)', "timezone": 'Indian/Mayotte'},
    'MX': {"name": 'Mexico', "code": '+52', "currency": 'MXN ($)', "timezone": 'America/Mexico_City'},
    'MD': {"name": 'Moldova', "code": '+373', "currency": 'MDL (MDL)', "timezone": 'Europe/Chisinau'},
    'MC': {"name": 'Monaco', "code": '+377', "currency": 'EUR (€)', "timezone": 'Europe/Monaco'},
    'MN': {"name": 'Mongolia', "code": '+976', "currency": 'MNT (₮)', "timezone": 'Asia/Ulaanbaatar'},
    'ME': {"name": 'Montenegro', "code": '+382', "currency": 'EUR (€)', "timezone": 'Europe/Podgorica'},
    'MS': {"name": 'Montserrat', "code": '+1664', "currency": 'XCD ($)', "timezone": 'America/Montserrat'},
    'MA': {"name": 'Morocco', "code": '+212', "currency": 'MAD (MAD)', "timezone": 'Africa/Casablanca'},
    'MZ': {"name": 'Mozambique', "code": '+258', "currency": 'MZN (MZN)', "timezone": 'Africa/Maputo'},
    'MM': {"name": 'Myanmar', "code": '+95', "currency": 'MMK (K)', "timezone": 'Asia/Yangon'},
    'NA': {"name": 'Namibia', "code": '+264', "currency": 'ZAR (R)', "timezone": 'Africa/Windhoek'},
    'NR': {"name": 'Nauru', "code": '+674', "currency": 'AUD ($)', "timezone": 'Pacific/Nauru'},
    'NP': {"name": 'Nepal', "code": '+977', "currency": 'NPR (Rs)', "timezone": 'Asia/Kathmandu'},
    'NL': {"name": 'Netherlands', "code": '+31', "currency": 'EUR (€)', "timezone": 'Europe/Amsterdam'},
    'NC': {"name": 'New Caledonia', "code": '+687', "currency": 'XPF (CFPF)', "timezone": 'Pacific/Noumea'},
    'NZ': {"name": 'New Zealand', "code": '+64', "currency": 'NZD ($)', "timezone": 'Pacific/Auckland'},
    'NI': {"name": 'Nicaragua', "code": '+505', "currency": 'NIO (C$)', "timezone": 'America/Managua'},
    'NE': {"name": 'Niger', "code": '+227', "currency": 'XOF (F CFA)', "timezone": 'Africa/Niamey'},
    'NG': {"name": 'Nigeria', "code": '+234', "currency": 'NGN (₦)', "timezone": 'Africa/Lagos'},
    'NU': {"name": 'Niue', "code": '+683', "currency": 'NZD ($)', "timezone": 'Pacific/Niue'},
    'NF': {"name": 'Norfolk Island', "code": '+672', "currency": 'AUD ($)', "timezone": 'Pacific/Norfolk'},
    'KP': {"name": 'North Korea', "code": '+850', "currency": 'KPW (₩)', "timezone": 'Asia/Pyongyang'},
    'MP': {"name": 'Northern Mariana Islands', "code": '+1670', "currency": 'USD ($)', "timezone": 'Pacific/Saipan'},
    'NO': {"name": 'Norway', "code": '+47', "currency": 'NOK (kr)', "timezone": 'Europe/Oslo'},
    'OM': {"name": 'Oman', "code": '+968', "currency": 'OMR (OMR)', "timezone": 'Asia/Muscat'},
    'PK': {"name": 'Pakistan', "code": '+92', "currency": 'PKR (Rs)', "timezone": 'Asia/Karachi'},
    'PW': {"name": 'Palau', "code": '+680', "currency": 'USD ($)', "timezone": 'Pacific/Palau'},
    'PS': {"name": 'Palestine', "code": '+970', "currency": 'ILS (₪)', "timezone": 'Asia/Gaza'},
    'PA': {"name": 'Panama', "code": '+507', "currency": 'PAB (PAB)', "timezone": 'America/Panama'},
    'PG': {"name": 'Papua New Guinea', "code": '+675', "currency": 'PGK (PGK)', "timezone": 'Pacific/Port_Moresby'},
    'PY': {"name": 'Paraguay', "code": '+595', "currency": 'PYG (₲)', "timezone": 'America/Asuncion'},
    'PE': {"name": 'Peru', "code": '+51', "currency": 'PEN (PEN)', "timezone": 'America/Lima'},
    'PH': {"name": 'Philippines', "code": '+63', "currency": 'PHP (₱)', "timezone": 'Asia/Manila'},
    'PN': {"name": 'Pitcairn Islands', "code": '+64', "currency": 'NZD ($)', "timezone": 'Pacific/Pitcairn'},
    'PL': {"name": 'Poland', "code": '+48', "currency": 'PLN (zł)', "timezone": 'Europe/Warsaw'},
    'PT': {"name": 'Portugal', "code": '+351', "currency": 'EUR (€)', "timezone": 'Europe/Lisbon'},
    'PR': {"name": 'Puerto Rico', "code": '+1787', "currency": 'USD ($)', "timezone": 'America/Puerto_Rico'},
    'QA': {"name": 'Qatar', "code": '+974', "currency": 'QAR (QAR)', "timezone": 'Asia/Qatar'},
    'MK': {"name": 'North Macedonia', "code": '+389', "currency": 'MKD (MKD)', "timezone": 'Europe/Skopje'},
    'CG': {"name": 'Republic of the Congo', "code": '+242', "currency": 'XAF (FCFA)', "timezone": 'Africa/Brazzaville'},
    'RO': {"name": 'Romania', "code": '+40', "currency": 'RON (lei)', "timezone": 'Europe/Bucharest'},
    'RU': {"name": 'Russia', "code": '+7', "currency": 'RUB (₽)', "timezone": 'Europe/Moscow'},
    'RW': {"name": 'Rwanda', "code": '+250', "currency": 'RWF (RF)', "timezone": 'Africa/Kigali'},
    'RE': {"name": 'Réunion', "code": '+262', "currency": 'EUR (€)', "timezone": 'Indian/Reunion'},
    'SH': {"name": 'Saint Helena', "code": '+290', "currency": 'SHP (£)', "timezone": 'Atlantic/St_Helena'},
    'KN': {"name": 'Saint Kitts and Nevis', "code": '+1869', "currency": 'XCD ($)', "timezone": 'America/St_Kitts'},
    'LC': {"name": 'Saint Lucia', "code": '+1758', "currency": 'XCD ($)', "timezone": 'America/St_Lucia'},
    'PM': {"name": 'Saint Pierre and Miquelon', "code": '+508', "currency": 'EUR (€)', "timezone": 'America/Miquelon'},
    'VC': {"name": 'Saint Vincent and the Grenadines', "code": '+1784', "currency": 'XCD ($)', "timezone": 'America/St_Vincent'},
    'WS': {"name": 'Samoa', "code": '+685', "currency": 'WST (WST)', "timezone": 'Pacific/Apia'},
    'SM': {"name": 'San Marino', "code": '+378', "currency": 'EUR (€)', "timezone": 'Europe/San_Marino'},
    'SA': {"name": 'Saudi Arabia', "code": '+966', "currency": 'SAR (SAR)', "timezone": 'Asia/Riyadh'},
    'SN': {"name": 'Senegal', "code": '+221', "currency": 'XOF (F CFA)', "timezone": 'Africa/Dakar'},
    'RS': {"name": 'Serbia', "code": '+381', "currency": 'RSD (RSD)', "timezone": 'Europe/Belgrade'},
    'SC': {"name": 'Seychelles', "code": '+248', "currency": 'SCR (SCR)', "timezone": 'Indian/Mahe'},
    'SL': {"name": 'Sierra Leone', "code": '+232', "currency": 'SLE (SLE)', "timezone": 'Africa/Freetown'},
    'SG': {"name": 'Singapore', "code": '+65', "currency": 'SGD ($)', "timezone": 'Asia/Singapore'},
    'SK': {"name": 'Slovakia', "code": '+421', "currency": 'EUR (€)', "timezone": 'Europe/Bratislava'},
    'SI': {"name": 'Slovenia', "code": '+386', "currency": 'EUR (€)', "timezone": 'Europe/Ljubljana'},
    'SB': {"name": 'Solomon Islands', "code": '+677', "currency": 'SBD ($)', "timezone": 'Pacific/Guadalcanal'},
    'SO': {"name": 'Somalia', "code": '+252', "currency": 'SOS (SOS)', "timezone": 'Africa/Mogadishu'},
    'ZA': {"name": 'South Africa', "code": '+27', "currency": 'ZAR (R)', "timezone": 'Africa/Johannesburg'},
    'GS': {"name": 'South Georgia', "code": '+500', "currency": 'GBP (£)', "timezone": 'Atlantic/South_Georgia'},
    'KR': {"name": 'South Korea', "code": '+82', "currency": 'KRW (₩)', "timezone": 'Asia/Seoul'},
    'SS': {"name": 'South Sudan', "code": '+211', "currency": 'SSP (£)', "timezone": 'Africa/Juba'},
    'ES': {"name": 'Spain', "code": '+34', "currency": 'EUR (€)', "timezone": 'Europe/Madrid'},
    'LK': {"name": 'Sri Lanka', "code": '+94', "currency": 'LKR (Rs)', "timezone": 'Asia/Colombo'},
    'SD': {"name": 'Sudan', "code": '+249', "currency": 'SDG (SDG)', "timezone": 'Africa/Khartoum'},
    'SR': {"name": 'Suriname', "code": '+597', "currency": 'SRD ($)', "timezone": 'America/Paramaribo'},
    'SJ': {"name": 'Svalbard and Jan Mayen', "code": '+4779', "currency": 'NOK (kr)', "timezone": 'Arctic/Longyearbyen'},
    'SZ': {"name": 'Eswatini', "code": '+268', "currency": 'SZL (SZL)', "timezone": 'Africa/Mbabane'},
    'SE': {"name": 'Sweden', "code": '+46', "currency": 'SEK (kr)', "timezone": 'Europe/Stockholm'},
    'CH': {"name": 'Switzerland', "code": '+41', "currency": 'CHF (CHF)', "timezone": 'Europe/Zurich'},
    'SY': {"name": 'Syria', "code": '+963', "currency": 'SYP (£)', "timezone": 'Asia/Damascus'},
    'ST': {"name": 'São Tomé and Príncipe', "code": '+239', "currency": 'STN (Db)', "timezone": 'Africa/Sao_Tome'},
    'TW': {"name": 'Taiwan', "code": '+886', "currency": 'TWD ($)', "timezone": 'Asia/Taipei'},
    'TJ': {"name": 'Tajikistan', "code": '+992', "currency": 'TJS (TJS)', "timezone": 'Asia/Dushanbe'},
    'TZ': {"name": 'Tanzania', "code": '+255', "currency": 'TZS (TZS)', "timezone": 'Africa/Dar_es_Salaam'},
    'TH': {"name": 'Thailand', "code": '+66', "currency": 'THB (฿)', "timezone": 'Asia/Bangkok'},
    'BS': {"name": 'Bahamas', "code": '+1242', "currency": 'BSD ($)', "timezone": 'America/Nassau'},
    'GM': {"name": 'Gambia', "code": '+220', "currency": 'GMD (GMD)', "timezone": 'Africa/Banjul'},
    'TG': {"name": 'Togo', "code": '+228', "currency": 'XOF (F CFA)', "timezone": 'Africa/Lome'},
    'TK': {"name": 'Tokelau', "code": '+690', "currency": 'NZD ($)', "timezone": 'Pacific/Fakaofo'},
    'TO': {"name": 'Tonga', "code": '+676', "currency": 'TOP (T$)', "timezone": 'Pacific/Tongatapu'},
    'TT': {"name": 'Trinidad and Tobago', "code": '+1868', "currency": 'TTD ($)', "timezone": 'America/Port_of_Spain'},
    'TN': {"name": 'Tunisia', "code": '+216', "currency": 'TND (TND)', "timezone": 'Africa/Tunis'},
    'TR': {"name": 'Türkiye', "code": '+90', "currency": 'TRY (₺)', "timezone": 'Europe/Istanbul'},
    'TM': {"name": 'Turkmenistan', "code": '+993', "currency": 'TMT (TMT)', "timezone": 'Asia/Ashgabat'},
    'TV': {"name": 'Tuvalu', "code": '+688', "currency": 'AUD ($)', "timezone": 'Pacific/Funafuti'},
    'UG': {"name": 'Uganda', "code": '+256', "currency": 'UGX (UGX)', "timezone": 'Africa/Kampala'},
    'UA': {"name": 'Ukraine', "code": '+380', "currency": 'UAH (₴)', "timezone": 'Europe/Kyiv'},
    'AE': {"name": 'United Arab Emirates', "code": '+971', "currency": 'AED (AED)', "timezone": 'Asia/Dubai'},
    'GB': {"name": 'United Kingdom', "code": '+44', "currency": 'GBP (£)', "timezone": 'Europe/London'},
    'US': {"name": 'United States', "code": '+1', "currency": 'USD ($)', "timezone": 'America/New_York'},
    'UY': {"name": 'Uruguay', "code": '+598', "currency": 'UYU ($)', "timezone": 'America/Montevideo'},
    'UZ': {"name": 'Uzbekistan', "code": '+998', "currency": 'UZS (UZS)', "timezone": 'Asia/Tashkent'},
    'VU': {"name": 'Vanuatu', "code": '+678', "currency": 'VUV (VUV)', "timezone": 'Pacific/Efate'},
    'VA': {"name": 'Vatican City', "code": '+39', "currency": 'EUR (€)', "timezone": 'Europe/Vatican'},
    'VE': {"name": 'Venezuela', "code": '+58', "currency": 'VES (VES)', "timezone": 'America/Caracas'},
    'VN': {"name": 'Vietnam', "code": '+84', "currency": 'VND (₫)', "timezone": 'Asia/Ho_Chi_Minh'},
    'WF': {"name": 'Wallis and Futuna', "code": '+681', "currency": 'XPF (CFPF)', "timezone": 'Pacific/Wallis'},
    'EH': {"name": 'Western Sahara', "code": '+212', "currency": 'MAD (MAD)', "timezone": 'Africa/El_Aaiun'},
    'YE': {"name": 'Yemen', "code": '+967', "currency": 'YER (YER)', "timezone": 'Asia/Aden'},
    'ZM': {"name": 'Zambia', "code": '+260', "currency": 'ZMW (ZK)', "timezone": 'Africa/Lusaka'},
    'ZW': {"name": 'Zimbabwe', "code": '+263', "currency": 'USD ($)', "timezone": 'Africa/Harare'},
}

def canonical_country_context(country: Optional[str], country_code: Optional[str]) -> dict:
    code = str(country_code or "").strip().upper()
    if code and code in COUNTRY_CONTEXTS:
        return COUNTRY_CONTEXTS[code]
    name = str(country or "").strip().casefold()
    for ctx in COUNTRY_CONTEXTS.values():
        if ctx["name"].casefold() == name:
            return ctx
    raise HTTPException(status_code=400, detail="Please select a valid country or region.")

def canonical_phone_for_country(raw: Optional[str], phone_country_code: str) -> str:
    digits = re.sub(r"\D", "", str(raw or ""))
    prefix_digits = re.sub(r"\D", "", phone_country_code or "")
    if not digits or not prefix_digits:
        return str(raw or "").strip()
    if digits.startswith(prefix_digits):
        local = digits[len(prefix_digits):]
    else:
        local = digits.lstrip("0")
    return f"{phone_country_code}{local}" if local else phone_country_code

def canonical_business_country_values(country: Optional[str], country_code: Optional[str], language: Optional[str] = "en") -> dict:
    ctx = canonical_country_context(country, country_code)
    lang = str(language or "en").strip().lower() or "en"
    iso2 = country_code.strip().upper() if country_code and country_code.strip().upper() in COUNTRY_CONTEXTS else next(k for k,v in COUNTRY_CONTEXTS.items() if v["name"] == ctx["name"])
    # Keep language independent. The country supplies the region component.
    return {
        "country": ctx["name"],
        "country_code": iso2,
        "currency": ctx["currency"],
        "phone_country_code": ctx["code"],
        "timezone": ctx.get("timezone") or "UTC",
        "locale": f"{lang}-{iso2}",
    }

# -----------------------------------------------------------------------------
# PROVIDERS
# -----------------------------------------------------------------------------
openai_client = None
if OpenAI and os.getenv("OPENAI_API_KEY"):
    openai_client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

gemini_client = None
if genai and os.getenv("GEMINI_API_KEY"):
    gemini_client = genai.Client(api_key=os.getenv("GEMINI_API_KEY"))

# -----------------------------------------------------------------------------
# DEPENDENCIES / HELPERS
# -----------------------------------------------------------------------------
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def normalize_username(value: str) -> str:
    return " ".join((value or "").strip().split()).casefold()

def normalize_phone(value: str) -> str:
    return re.sub(r"\D", "", value or "")

def hash_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()

def decode_base64_upload(file_data: str, allowed_content_types: set[str]) -> tuple[bytes, str]:
    """Decode a browser data URL without trusting its name or MIME declaration."""
    if not isinstance(file_data, str) or not file_data.startswith("data:") or "," not in file_data:
        raise HTTPException(status_code=422, detail="The uploaded file could not be read.")
    header, encoded = file_data.split(",", 1)
    match = re.fullmatch(r"data:([A-Za-z0-9.+/-]+);base64", header.strip(), flags=re.IGNORECASE)
    if not match:
        raise HTTPException(status_code=422, detail="The uploaded file format is not supported.")
    content_type = match.group(1).lower()
    if content_type not in allowed_content_types:
        raise HTTPException(status_code=422, detail="This file type is not allowed.")
    try:
        raw = base64.b64decode(encoded, validate=True)
    except Exception as exc:
        raise HTTPException(status_code=422, detail="The uploaded file could not be decoded.") from exc
    if not raw or len(raw) > MAX_UPLOAD_BYTES:
        raise HTTPException(status_code=422, detail=f"Upload must be between 1 byte and {MAX_UPLOAD_BYTES} bytes.")
    return raw, content_type

def safe_upload_name(value: str, fallback: str) -> str:
    name = Path(str(value or "")).name.strip()
    name = re.sub(r"[^A-Za-z0-9._ -]+", "_", name).strip(" .")
    return (name or fallback)[:180]

def persist_upload(db: Session, user: User, kind: str, original_name: str, content_type: str, raw: bytes) -> StoredUpload:
    """Save bytes privately and create an auditable, business-scoped record."""
    business = db.query(BusinessProfile).filter(BusinessProfile.id == user.business_id).first()
    check_storage_limit(db, business, len(raw))
    suffix = Path(original_name).suffix.lower()
    row = StoredUpload(
        business_id=user.business_id,
        uploaded_by_id=user.id,
        kind=kind,
        original_name=safe_upload_name(original_name, f"{kind}-upload"),
        storage_key="pending",
        content_type=content_type,
        size_bytes=len(raw),
        content_hash=hashlib.sha256(raw).hexdigest(),
    )
    db.add(row)
    db.flush()
    key = f"{user.business_id}/{row.id}-{secrets.token_urlsafe(18)}{suffix}"
    target = (UPLOAD_STORAGE_DIR / key).resolve()
    if UPLOAD_STORAGE_DIR not in target.parents:
        raise HTTPException(status_code=500, detail="The upload storage location is invalid.")
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_suffix(target.suffix + ".tmp")
    try:
        temporary.write_bytes(raw)
        os.replace(temporary, target)
    except OSError as exc:
        temporary.unlink(missing_ok=True)
        raise HTTPException(status_code=503, detail="The server could not securely store the uploaded file.") from exc
    row.storage_key = key
    return row

def hash_password(password: str) -> str:
    return pwd_context.hash(password)

def verify_password(password: str, hashed: str) -> bool:
    try:
        return pwd_context.verify(password, hashed)
    except Exception:
        return False

def validate_password_strength(password: str):
    if len(password) > 72:
        raise HTTPException(status_code=400, detail="Password must be 72 characters or fewer.")
    if len(password) < 8 or not re.search(r"[A-Z]", password) or not re.search(r"[a-z]", password) or not re.search(r"\d", password):
        raise HTTPException(status_code=400, detail="Password must be at least 8 characters and include uppercase, lowercase, and a number.")

def generate_dynamic_business_code(db: Session, business_name: str) -> str:
    words = business_name.strip().split()
    initials = ((words[0][0] + words[1][0]) if len(words) >= 2 else (words[0][:2] if words else "BX")).upper()
    for _ in range(50):
        code = f"{initials}-{random.randint(1000,9999)}-{random.randint(10,99)}"
        if not db.query(BusinessProfile).filter(BusinessProfile.business_code == code).first():
            return code
    raise HTTPException(status_code=500, detail="We could not create a unique Business ID. Please try again.")

def get_business_by_code(db: Session, business_code: str) -> Optional[BusinessProfile]:
    cleaned = re.sub(r"[^A-Za-z0-9]", "", (business_code or "")).casefold()
    if not cleaned:
        return None
    businesses = db.query(BusinessProfile).all()
    return next((b for b in businesses if re.sub(r"[^A-Za-z0-9]", "", b.business_code).casefold() == cleaned), None)

def issue_token(user: User, db: Session) -> str:
    exp = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    jti = secrets.token_urlsafe(24)
    payload = {"sub": str(user.id), "business_id": user.business_id, "role": user.role, "jti": jti, "auth_version": int(user.auth_version or 1), "exp": exp}
    return jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)

def revoke_all_user_sessions(db: Session, user: User):
    now = datetime.utcnow()
    db.query(RefreshSession).filter(RefreshSession.user_id == user.id, RefreshSession.revoked_at.is_(None)).update({RefreshSession.revoked_at: now}, synchronize_session=False)
    user.auth_version = int(user.auth_version or 1) + 1

def create_refresh_session(db: Session, user: User) -> str:
    raw = secrets.token_urlsafe(48)
    row = RefreshSession(token_hash=hash_text(raw), user_id=user.id, business_id=user.business_id, expires_at=datetime.utcnow()+timedelta(days=REFRESH_TOKEN_EXPIRE_DAYS))
    db.add(row); db.commit()
    return raw

def set_refresh_cookie(response: Response, raw: str):
    response.set_cookie(key=REFRESH_COOKIE_NAME, value=raw, httponly=True, secure=REFRESH_COOKIE_SECURE, samesite=REFRESH_COOKIE_SAMESITE if REFRESH_COOKIE_SAMESITE in {"lax","strict","none"} else "lax", max_age=REFRESH_TOKEN_EXPIRE_DAYS*86400, path="/")

def clear_refresh_cookie(response: Response):
    response.delete_cookie(REFRESH_COOKIE_NAME, path="/")

def token_from_payload(token: str) -> tuple[dict, str]:
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        jti = payload.get("jti")
        if not jti: raise JWTError("Missing token id")
        return payload, jti
    except JWTError:
        raise HTTPException(status_code=401, detail="Your session could not be verified. Please sign in again.")

def require_active_user(user: User):
    if user.disabled:
        raise HTTPException(status_code=403, detail="This account is currently disabled.")
    return user

def get_authenticated_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)) -> User:
    payload, jti = token_from_payload(token)
    if db.query(SessionRevocation).filter(SessionRevocation.jti == jti).first():
        raise HTTPException(status_code=401, detail="Your session is no longer valid. Please sign in again.")
    try:
        uid=int(payload.get("sub")); bid=int(payload.get("business_id")); av=int(payload.get("auth_version",0))
    except Exception:
        raise HTTPException(status_code=401, detail="Your session could not be verified. Please sign in again.")
    user=db.query(User).filter(User.id==uid, User.business_id==bid).first()
    if not user: raise HTTPException(status_code=401, detail="Your session could not be verified. Please sign in again.")
    require_active_user(user)
    if av and av != int(user.auth_version or 1):
        raise HTTPException(status_code=401, detail="Your session is no longer valid. Please sign in again.")
    return user

def get_current_user(user: User = Depends(get_authenticated_user), db: Session = Depends(get_db)) -> User:
    if user.must_change_password:
        raise HTTPException(status_code=403, detail="You must change your temporary password before using the application.")
    require_subscription_access(db, user)
    return user

def add_audit(db: Session, user: Optional[User], action: str, description: str, target: Optional[User] = None, business_id: Optional[int] = None):
    actor_role = user.role if user else None
    actor_username = user.username if user else None
    bid = business_id or (user.business_id if user else None)
    if not bid:
        return
    db.add(AuditLog(
        business_id=bid,
        actor_user_id=user.id if user else None,
        actor_username=actor_username,
        actor_role=actor_role,
        action=action,
        target_user_id=target.id if target else None,
        target_username=target.username if target else None,
        description=description,
    ))

def fail_key(scope: str, key: str) -> str:
    return hash_text(f"{scope}:{key}")

def check_rate_limit(db: Session, scope: str, key: str):
    k = fail_key(scope, key)
    row = db.query(AuthFailure).filter(AuthFailure.scope == scope, AuthFailure.key_hash == k).first()
    now = datetime.utcnow()
    if not row:
        return
    if row.locked_until and row.locked_until > now:
        seconds = int((row.locked_until - now).total_seconds())
        raise HTTPException(status_code=429, detail=f"Too many attempts. Please wait {max(1, seconds)} seconds and try again.")
    if (now - row.window_started_at).total_seconds() > RATE_LIMIT_WINDOW_SECONDS:
        row.failures = 0
        row.window_started_at = now
        row.locked_until = None
        db.commit()

def record_failure(db: Session, scope: str, key: str):
    k = fail_key(scope, key)
    now = datetime.utcnow()
    row = db.query(AuthFailure).filter(AuthFailure.scope == scope, AuthFailure.key_hash == k).first()
    if not row:
        row = AuthFailure(scope=scope, key_hash=k, failures=0, window_started_at=now)
        db.add(row)
    if (now - row.window_started_at).total_seconds() > RATE_LIMIT_WINDOW_SECONDS:
        row.failures = 0
        row.window_started_at = now
    row.failures += 1
    if row.failures >= RATE_LIMIT_MAX_FAILURES:
        row.locked_until = now + timedelta(seconds=RATE_LIMIT_WINDOW_SECONDS)
    db.commit()

def clear_failures(db: Session, scope: str, key: str):
    k = fail_key(scope, key)
    row = db.query(AuthFailure).filter(AuthFailure.scope == scope, AuthFailure.key_hash == k).first()
    if row:
        db.delete(row)
        db.commit()

def parse_iso_datetime(value: Optional[str]) -> Optional[datetime]:
    if not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00")).replace(tzinfo=None)
    except Exception:
        return None

def serialize_user(u: User) -> dict:
    return {
        "id": u.id, "username": u.username, "role": u.role, "email": u.email, "phone": u.phone,
        "firstname": u.firstname, "lastname": u.lastname, "position": u.position,
        "must_change_password": u.must_change_password, "disabled": u.disabled,
    }

def serialize_business(b: BusinessProfile) -> dict:
    return {
        # Keep the business identifier explicit when this object is combined with
        # a user object in an authentication response. Both models have an id.
        "id": b.id, "business_id": b.id, "business_code": b.business_code, "company_name": b.company_name,
        "email": b.email, "phone": b.phone, "address": b.address, "currency": b.currency,
        "tax_id": b.tax_id, "country": b.country, "country_code": b.country_code,
        "locale": b.locale, "language": b.language, "timezone": b.timezone,
        "phone_country_code": b.phone_country_code,
        "subscription_plan": (b.subscription_plan or "starter").lower(), "billing_interval": b.billing_interval or "monthly",
    }

def auto_upsert_general_catalog(db: Session, product: Product):
    barcode=(product.barcode or "").strip() or None
    key=f"barcode:{barcode}" if barcode else f"name:{(product.name or '').strip().casefold()}|category:{(product.category or 'General').strip().casefold()}"
    item=db.query(GeneralCatalog).filter(GeneralCatalog.catalog_key==key).first()
    if item:
        item.product_name=product.name or item.product_name; item.category=product.category or item.category; item.barcode=barcode or item.barcode; item.updated_at=datetime.utcnow(); return
    if barcode:
        item=db.query(GeneralCatalog).filter(GeneralCatalog.barcode==barcode).first()
        if item:
            item.catalog_key=f"barcode:{barcode}"; item.product_name=product.name or item.product_name; item.category=product.category or item.category; item.updated_at=datetime.utcnow(); return
    db.add(GeneralCatalog(barcode=barcode,catalog_key=key,product_name=product.name,category=product.category))

def ensure_open_business_day(db: Session, business_id: int) -> BusinessDay:
    today = datetime.utcnow().date().isoformat()
    day = db.query(BusinessDay).filter(BusinessDay.business_id == business_id, BusinessDay.date == today).first()
    if not day:
        day = BusinessDay(business_id=business_id, date=today, is_open=True)
        db.add(day)
        db.commit(); db.refresh(day)
    return day

def build_alerts(db: Session, business_id: int):
    # Create durable low-stock/expiry alerts only when one does not already exist recently.
    now = datetime.utcnow()
    products = db.query(Product).filter(Product.business_id == business_id).all()
    for p in products:
        if p.quantity <= p.min_stock_level:
            exists = db.query(Alert).filter(Alert.business_id == business_id, Alert.type == "low_stock", Alert.message.contains(p.name), Alert.created_at >= now - timedelta(days=1)).first()
            if not exists:
                db.add(Alert(business_id=business_id, type="low_stock", title="Low stock", message=f"{p.name} has {p.quantity} units remaining against a minimum of {p.min_stock_level}.", severity="warning"))
        if p.expiry_date:
            days = (p.expiry_date.date() - now.date()).days
            if 0 <= days <= 60:
                exists = db.query(Alert).filter(Alert.business_id == business_id, Alert.type == "expiry", Alert.message.contains(p.name), Alert.created_at >= now - timedelta(days=1)).first()
                if not exists:
                    db.add(Alert(business_id=business_id, type="expiry", title="Product approaching expiry", message=f"{p.name} expires in {days} day(s). Please review this stock.", severity="warning"))
    db.commit()

def format_alerts_for_user(db: Session, user: User, limit=50, offset=0):
    build_alerts(db, user.business_id)
    rows = db.query(Alert).filter(Alert.business_id == user.business_id).order_by(Alert.created_at.desc()).offset(offset).limit(limit).all()
    read_ids = {x.alert_id for x in db.query(AlertRead).filter(AlertRead.user_id == user.id).all()}
    result = []
    for a in rows:
        if a.id in read_ids:
            continue
        result.append({"id": a.id, "type": a.type, "title": a.title, "message": a.message, "severity": a.severity, "created_at": a.created_at.isoformat()})
    return result

def gemini_text_response(system_prompt: str, user_prompt: str) -> str:
    if not gemini_client:
        raise HTTPException(status_code=503, detail="Gemini AI is not configured. Add GEMINI_API_KEY to the server environment.")
    try:
        response = gemini_client.models.generate_content(model=GEMINI_MODEL, contents=f"{system_prompt}\n\n{user_prompt}")
        text = getattr(response, "text", None) or ""
        if not text.strip(): raise ValueError("Empty Gemini response")
        return text.strip()
    except Exception as exc:
        raise HTTPException(status_code=502, detail="Gemini could not complete that AI operation right now. Please try again.") from exc

def openai_json_response(prompt: str, image_data: Optional[str] = None) -> dict:
    if not openai_client:
        raise HTTPException(status_code=503, detail="OpenAI integration is not configured. Add OPENAI_API_KEY to the server environment.")
    content = [{"type": "input_text", "text": prompt}]
    if image_data:
        content.append({"type": "input_image", "image_url": image_data, "detail": "high"})
    schema = {
        "type": "object",
        "properties": {
            "supplier_name": {"type": "string"},
            "invoice_number": {"type": "string"},
            "invoice_date": {"type": "string"},
            "items": {"type": "array", "items": {"type": "object", "properties": {
                "description": {"type": "string"}, "quantity": {"type": "number"}, "unit_price": {"type": "number"}
            }, "required": ["description", "quantity", "unit_price"], "additionalProperties": False}},
            "subtotal": {"type": "number"}, "total": {"type": "number"}
        },
        "required": ["supplier_name", "invoice_number", "invoice_date", "items", "subtotal", "total"],
        "additionalProperties": False,
    }
    resp = openai_client.responses.create(
        model=OPENAI_MODEL,
        input=[{"role": "user", "content": content}],
        text={"format": {"type": "json_schema", "name": "invoice_extraction", "schema": schema, "strict": True}},
    )
    text = getattr(resp, "output_text", "")
    try:
        return json.loads(text)
    except Exception as exc:
        raise HTTPException(status_code=502, detail="The invoice could not be interpreted reliably. Please review it manually.") from exc

# -----------------------------------------------------------------------------
# SCHEMAS
# -----------------------------------------------------------------------------
class RegisterBusinessRequest(BaseModel):
    company_name: str
    email: EmailStr
    phone: str
    address: Optional[str] = None
    currency: str = "USD ($)"
    tax_id: Optional[str] = None
    firstname: str
    lastname: str
    owner_email: EmailStr
    owner_phone: str
    username: str
    password: str
    position: str = "Admin"
    country: Optional[str] = None
    country_code: Optional[str] = None
    locale: Optional[str] = None
    language: Optional[str] = "en"
    timezone: Optional[str] = "UTC"
    phone_country_code: Optional[str] = None
    plan: str = "starter"
    billing_interval: str = "monthly"

class BusinessVerifyRequest(BaseModel):
    business_id: str

class AdminLoginRequest(BaseModel):
    business_id: str
    username: str
    password: str

class EmployeeLoginRequest(BaseModel):
    business_id: str
    username: str
    password: str
    selected_role: str

class CreateUserRequest(BaseModel):
    username: str
    password: str
    role: str
    firstname: str
    lastname: str
    email: EmailStr
    phone: str
    position: str

class BusinessProfileSchema(BaseModel):
    company_name: str
    email: Optional[str] = None
    phone: Optional[str] = None
    address: Optional[str] = None
    currency: str = "USD ($)"
    tax_id: Optional[str] = None
    country: Optional[str] = None
    country_code: Optional[str] = None
    locale: Optional[str] = "en-US"
    language: Optional[str] = "en"
    timezone: Optional[str] = "UTC"
    phone_country_code: Optional[str] = None

class WarehouseCreate(BaseModel):
    name: str

class WarehouseUpdate(BaseModel):
    name: str
    is_active: Optional[bool] = None

class ProductCreate(BaseModel):
    barcode: Optional[str] = None
    sku: Optional[str] = None
    name: str
    category: str
    size: Optional[str] = None
    quantity: int
    min_stock_level: int
    cost_price: float
    wholesale_price: Optional[float] = 0.0
    retail_price: float
    warehouse: Optional[str] = "Main Central Warehouse"
    expiry_date: Optional[datetime] = None

class ProductUpdate(BaseModel):
    barcode: Optional[str] = None
    name: Optional[str] = None
    sku: Optional[str] = None
    category: Optional[str] = None
    size: Optional[str] = None
    quantity: Optional[int] = Field(default=None, ge=0)
    min_stock_level: Optional[int] = Field(default=None, ge=0)
    cost_price: Optional[float] = Field(default=None, ge=0)
    wholesale_price: Optional[float] = Field(default=None, ge=0)
    retail_price: Optional[float] = Field(default=None, ge=0)
    warehouse: Optional[str] = None
    expiry_date: Optional[datetime] = None

class StockUpdate(BaseModel):
    quantity_change: int
    action_type: str = "MANUAL"

class StockTransfer(BaseModel):
    from_warehouse: str
    to_warehouse: str
    quantity: int = Field(ge=1)

class SupplierCreate(BaseModel):
    name: str
    contact_email: Optional[str] = None
    phone: str
    lead_time_days: Optional[int] = 3

class PODraftUpdate(BaseModel):
    details: Optional[str] = None
    items_summary: Optional[str] = None
    supplier_id: Optional[int] = None

class PasswordChangeRequest(BaseModel):
    current_password: str
    new_password: str

class AdminPasswordResetRequest(BaseModel):
    new_password: str

class MarginRequest(BaseModel):
    name: str
    category: str
    cost_price: float

class ChatRequest(BaseModel):
    message: str

class BarcodeScanRequest(BaseModel):
    barcode: str

class InvoiceScanRequest(BaseModel):
    image_data: str
    file_name: Optional[str] = None

class AccountActionRequestCreate(BaseModel):
    target_user_id: int
    action: str

class PriceSourceCreate(BaseModel):
    supplier_id: int
    product_id: int
    source_type: str = "manual"
    source_url: Optional[str] = None
    initial_price: Optional[float] = None

class ManualPriceUpdate(BaseModel):
    price: float

class SalesCheckoutItem(BaseModel):
    product_id: int
    quantity: int
    unit_price: float

class SalesCheckoutRequest(BaseModel):
    items: List[SalesCheckoutItem]

class PresenceHeartbeatRequest(BaseModel):
    session_id: Optional[str] = None

class PriceListUploadRequest(BaseModel):
    supplier_id: int
    product_id: Optional[int] = None
    file_name: str
    file_data: str

class ForgotPasswordRequest(BaseModel):
    business_id: str
    username: str
    email: EmailStr
    channel: str = "email"

class PasswordResetRequest(BaseModel):
    recovery_id: str
    code: str
    new_password: str

class AuditLogSchema(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    actor_username: Optional[str]
    actor_role: Optional[str]
    action: str
    target_username: Optional[str]
    description: str
    created_at: datetime

# -----------------------------------------------------------------------------
# AUTH
# -----------------------------------------------------------------------------
@app.post("/auth/register-business")
def register_business(data: RegisterBusinessRequest, request: Request, response: Response, db: Session = Depends(get_db)):
    validate_password_strength(data.password)
    normalized = normalize_username(data.username)
    plan = str(data.plan or "starter").strip().lower()
    if plan not in PLAN_CONFIG:
        raise HTTPException(status_code=400, detail="Please choose a valid subscription plan.")
    billing_interval = str(data.billing_interval or "monthly").strip().lower()
    if billing_interval not in ("monthly", "annual"):
        billing_interval = "monthly"
    country_values = canonical_business_country_values(data.country, data.country_code, data.language)
    language = str(data.language or "en").strip().lower() or "en"
    canonical_owner_phone = canonical_phone_for_country(data.owner_phone, country_values["phone_country_code"])

    # Risk signal only (never a hard block): flag when this owner identity has
    # started a trial before, for later review. A shared email/phone across
    # legitimate multi-business owners must not be auto-punished.
    prior_trial_admin = db.query(User).join(BusinessSubscription, BusinessSubscription.business_id == User.business_id).filter(
        User.role == "admin", BusinessSubscription.trial_start_at.isnot(None),
        or_(User.email == str(data.owner_email), User.phone == canonical_owner_phone)
    ).first()

    # Uniqueness is business-scoped, and the initial business has no users yet.
    new_biz = BusinessProfile(
        business_code=generate_dynamic_business_code(db, data.company_name),
        company_name=data.company_name,
        email=str(data.email),
        phone=canonical_phone_for_country(data.phone, country_values["phone_country_code"]),
        address=data.address,
        currency=country_values["currency"],
        tax_id=data.tax_id,
        country=country_values["country"],
        country_code=country_values["country_code"],
        locale=country_values["locale"],
        language=language,
        timezone=country_values["timezone"],
        phone_country_code=country_values["phone_country_code"],
        subscription_plan=plan,
        billing_interval=billing_interval,
    )
    db.add(new_biz); db.commit(); db.refresh(new_biz)
    admin = User(
        username=data.username.strip(), password=hash_password(data.password), role="admin",
        firstname=data.firstname, lastname=data.lastname, position=data.position or "Admin",
        email=str(data.owner_email), phone=canonical_owner_phone, business_id=new_biz.id,
        must_change_password=False, disabled=False, auth_version=1
    )
    db.add(admin); db.commit(); db.refresh(admin)
    db.add(Warehouse(business_id=new_biz.id, name="Main Central Warehouse", is_active=True))

    now = datetime.utcnow()
    trial_end = now + timedelta(days=PLAN_CONFIG[plan]["trial_days"])
    db.add(BusinessSubscription(
        business_id=new_biz.id, plan=plan, billing_interval=billing_interval, status="trialing",
        trial_start_at=now, trial_end_at=trial_end, current_period_start=now, current_period_end=trial_end,
    ))

    add_audit(db, admin, "BUSINESS_REGISTERED", f"Business and owner Admin account registered on the {PLAN_CONFIG[plan]['label']} plan.", admin)
    if prior_trial_admin:
        client_ip = request.client.host if request.client else "unknown"
        add_audit(db, admin, "TRIAL_RISK_SIGNAL", f"Owner identity (email/phone) previously started a trial for another business (ip={client_ip}). Flagged for review only; trial not restricted.", admin)
    db.commit()
    access = issue_token(admin, db)
    set_refresh_cookie(response, create_refresh_session(db, admin))
    return {"access_token": access, "token_type": "bearer", "business_code": new_biz.business_code, **serialize_business(new_biz), **serialize_user(admin)}

@app.post("/auth/verify-business")
def verify_business(data: BusinessVerifyRequest, request: Request, db: Session = Depends(get_db)):
    key = re.sub(r"\W", "", data.business_id or "").casefold()
    client_ip = request.client.host if request.client else "unknown"
    check_rate_limit(db, "business-verify-ip", client_ip)
    check_rate_limit(db, "business-verify-code", key or "blank")
    biz = get_business_by_code(db, data.business_id)
    if not biz:
        record_failure(db, "business-verify-ip", client_ip)
        record_failure(db, "business-verify-code", key or "blank")
        raise HTTPException(status_code=404, detail="Business not found. Please check the Business ID and try again.")
    clear_failures(db, "business-verify-ip", client_ip)
    return serialize_business(biz)

def authenticate_user_for_business(db: Session, business_code: str, username: str, password: str, role: Optional[str] = None, scope: str = "login", client_ip: Optional[str] = None) -> User:
    biz = get_business_by_code(db, business_code)
    if not biz:
        raise HTTPException(status_code=404, detail="Business not found. Please check the Business ID and try again.")
    key = f"{biz.id}:{normalize_username(username)}"
    check_rate_limit(db, scope, key)
    if client_ip:
        check_rate_limit(db, scope + "-ip", client_ip)
    user = next((u for u in db.query(User).filter(User.business_id == biz.id).all() if normalize_username(u.username) == normalize_username(username)), None)
    if not user or not verify_password(password, user.password) or user.disabled:
        record_failure(db, scope, key)
        if client_ip: record_failure(db, scope + "-ip", client_ip)
        raise HTTPException(status_code=401, detail="Incorrect username or password.")
    clear_failures(db, scope, key)
    if client_ip: clear_failures(db, scope + "-ip", client_ip)
    if role and user.role != role:
        raise HTTPException(status_code=403, detail="This account does not have the selected role.")
    return user

@app.post("/auth/admin-login")
def admin_login(data: AdminLoginRequest, request: Request, response: Response, db: Session = Depends(get_db)):
    user = authenticate_user_for_business(db, data.business_id, data.username, data.password, role="admin", scope="admin-login", client_ip=request.client.host if request.client else "unknown")
    biz = db.query(BusinessProfile).filter(BusinessProfile.id == user.business_id).first()
    access = issue_token(user, db)
    set_refresh_cookie(response, create_refresh_session(db, user))
    return {"access_token": access, "token_type": "bearer", **serialize_business(biz), **serialize_user(user)}

@app.post("/auth/employee-login")
def employee_login(data: EmployeeLoginRequest, request: Request, response: Response, db: Session = Depends(get_db)):
    if data.selected_role not in {"manager", "staff"}:
        raise HTTPException(status_code=400, detail="Select Manager or Staff for employee login.")
    user = authenticate_user_for_business(db, data.business_id, data.username, data.password, role=data.selected_role, scope="employee-login", client_ip=request.client.host if request.client else "unknown")
    biz = db.query(BusinessProfile).filter(BusinessProfile.id == user.business_id).first()
    access = issue_token(user, db)
    set_refresh_cookie(response, create_refresh_session(db, user))
    return {"access_token": access, "token_type": "bearer", **serialize_business(biz), **serialize_user(user)}

@app.post("/token")
def login(form_data: OAuth2PasswordRequestForm = Depends(), request: Request = None, response: Response = None, db: Session = Depends(get_db)):
    # OAuth2 compatibility route: if a business code is supplied in 'scope', honor it.
    business_code = form_data.scopes[0] if form_data.scopes else ""
    if not business_code:
        raise HTTPException(status_code=400, detail="Business ID is required for token login.")
    user = authenticate_user_for_business(db, business_code, form_data.username, form_data.password, scope="token-login", client_ip=request.client.host if request and request.client else "unknown")
    biz = db.query(BusinessProfile).filter(BusinessProfile.id == user.business_id).first()
    access = issue_token(user, db)
    if response is not None: set_refresh_cookie(response, create_refresh_session(db, user))
    return {"access_token": access, "token_type": "bearer", **serialize_business(biz), **serialize_user(user)}

@app.get("/auth/me")
def auth_me(user: User = Depends(get_authenticated_user), db: Session = Depends(get_db)):
    biz = db.query(BusinessProfile).filter(BusinessProfile.id == user.business_id).first()
    return {**serialize_business(biz), **serialize_user(user)}

@app.post("/auth/logout")
def auth_logout(response: Response, token: str = Depends(oauth2_scheme), refresh_token: Optional[str] = Cookie(default=None, alias=REFRESH_COOKIE_NAME), user: User = Depends(get_authenticated_user), db: Session = Depends(get_db)):
    payload, jti = token_from_payload(token)
    exp_ts = payload.get("exp")
    exp_dt = datetime.utcfromtimestamp(exp_ts) if exp_ts else datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    if not db.query(SessionRevocation).filter(SessionRevocation.jti == jti).first():
        db.add(SessionRevocation(jti=jti, user_id=user.id, expires_at=exp_dt)); db.commit()
    if refresh_token:
        rs = db.query(RefreshSession).filter(RefreshSession.token_hash==hash_text(refresh_token), RefreshSession.user_id==user.id, RefreshSession.revoked_at.is_(None)).first()
        if rs: rs.revoked_at = datetime.utcnow()
    add_audit(db, user, "LOGOUT", "User signed out."); db.commit(); clear_refresh_cookie(response)
    return {"message": "Signed out successfully."}

@app.post("/auth/refresh")
def auth_refresh(response: Response, refresh_token: Optional[str] = Cookie(default=None, alias=REFRESH_COOKIE_NAME), db: Session = Depends(get_db)):
    # A page can load without a session (new visitor, signed-out user, or an
    # expired browser cookie). That is a normal state, not an authentication
    # error, so return an explicit empty success response without a console 401.
    if not refresh_token:
        clear_refresh_cookie(response)
        response.status_code = status.HTTP_204_NO_CONTENT
        return response
    row=db.query(RefreshSession).filter(RefreshSession.token_hash==hash_text(refresh_token)).first()
    if not row or row.revoked_at or row.expires_at <= datetime.utcnow():
        clear_refresh_cookie(response)
        response.status_code = status.HTTP_204_NO_CONTENT
        return response
    user=db.query(User).filter(User.id==row.user_id, User.business_id==row.business_id).first()
    if not user or user.disabled:
        row.revoked_at=datetime.utcnow(); db.commit(); clear_refresh_cookie(response)
        response.status_code = status.HTTP_204_NO_CONTENT
        return response
    row.revoked_at=datetime.utcnow(); new_raw=create_refresh_session(db,user); row.replaced_by_hash=hash_text(new_raw); db.commit()
    set_refresh_cookie(response,new_raw)
    biz=db.query(BusinessProfile).filter(BusinessProfile.id==user.business_id).first()
    return {"access_token": issue_token(user,db),"token_type":"bearer",**serialize_business(biz),**serialize_user(user)}

@app.post("/auth/change-password")
def change_password(data: PasswordChangeRequest, response: Response, user: User = Depends(get_authenticated_user), db: Session = Depends(get_db)):
    validate_password_strength(data.new_password)
    if not verify_password(data.current_password, user.password):
        raise HTTPException(status_code=400, detail="Incorrect current or temporary password.")
    if user.previous_password_hash and verify_password(data.new_password, user.previous_password_hash):
        raise HTTPException(status_code=400, detail="Last created password cannot be used.")
    user.previous_password_hash = user.password
    user.password = hash_password(data.new_password)
    user.must_change_password = False
    # Invalidate both refresh sessions and already issued access tokens.
    revoke_all_user_sessions(db, user)
    add_audit(db, user, "PASSWORD_CHANGED", "User changed their password.")
    db.commit()
    set_refresh_cookie(response, create_refresh_session(db, user))
    return {"message": "Password updated successfully.", "access_token": issue_token(user, db), "token_type": "bearer"}

@app.delete("/auth/account")
def delete_own_account(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if user.role == "admin":
        raise HTTPException(status_code=403, detail="Business owner accounts cannot self-delete. Use the business recovery/closure process.")
    add_audit(db, user, "ACCOUNT_DELETED", "User deleted their own account.", user)
    user.disabled = True
    db.commit()
    return {"message": "Account disabled successfully."}

# -----------------------------------------------------------------------------
# PASSWORD RECOVERY / EMAIL
# -----------------------------------------------------------------------------
def send_recovery_email(to_email: str, username: str, code: str):
    api_key = os.getenv("RESEND_API_KEY", "").strip()
    if not api_key:
        raise HTTPException(status_code=503, detail="Email recovery is not configured. Add RESEND_API_KEY to the server environment.")
    import requests
    try:
        r = requests.post(
            "https://api.resend.com/emails",
            headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
            json={
                "from": RESEND_FROM,
                "to": [to_email],
                "subject": f"{APP_NAME} password recovery code",
                "html": f"<p>Hello {username},</p><p>Your password recovery code is <strong>{code}</strong>.</p><p>This code expires in 10 minutes.</p>",
            },
            timeout=15,
        )
        if not r.ok:
            raise RuntimeError(r.text)
    except Exception as exc:
        raise HTTPException(status_code=502, detail="We could not send the recovery email right now.") from exc

def send_recovery_sms(phone: str, code: str):
    termii_key = os.getenv("TERMII_API_KEY", "").strip()
    twilio_sid = os.getenv("TWILIO_ACCOUNT_SID", "").strip()
    twilio_token = os.getenv("TWILIO_AUTH_TOKEN", "").strip()
    twilio_from = os.getenv("TWILIO_FROM", "").strip()
    # Termii-first is intentional. If Termii isn't configured, fall back to Twilio if configured.
    if termii_key:
        import requests
        try:
            r = requests.post(f"{TERMII_BASE_URL}/api/sms/send", json={
                "to": phone, "from": os.getenv("TERMII_SENDER_ID", "Cauldra"),
                "sms": f"Cauldra password recovery code: {code}. Expires in 10 minutes.",
                "type": "plain", "channel": "generic", "api_key": termii_key
            }, timeout=15)
            if r.ok:
                return
        except Exception:
            pass
    if twilio_sid and twilio_token and twilio_from:
        import requests
        try:
            auth = base64.b64encode(f"{twilio_sid}:{twilio_token}".encode()).decode()
            r = requests.post(
                f"https://api.twilio.com/2010-04-01/Accounts/{twilio_sid}/Messages.json",
                data={"To": phone, "From": twilio_from, "Body": f"Cauldra password recovery code: {code}. Expires in 10 minutes."},
                headers={"Authorization": f"Basic {auth}"}, timeout=15,
            )
            if r.ok:
                return
        except Exception:
            pass
    raise HTTPException(status_code=503, detail="SMS recovery is not configured or the SMS provider could not deliver the code.")

@app.post("/auth/forgot-password")
def forgot_password(payload: ForgotPasswordRequest, request: Request, db: Session = Depends(get_db)):
    business_id = payload.business_id.strip()
    username = payload.username.strip()
    email = str(payload.email).strip()
    channel = payload.channel.strip().lower()
    if channel not in {"email", "sms"}:
        raise HTTPException(status_code=400, detail="Choose email or SMS for password recovery.")
    biz = get_business_by_code(db, business_id)
    if not biz:
        raise HTTPException(status_code=404, detail="Business not found. Please check the Business ID and try again.")
    key = f"{biz.id}:{normalize_username(username)}:{channel}"
    client_ip = request.client.host if request.client else "unknown"
    check_rate_limit(db, "forgot-password", key)
    check_rate_limit(db, "forgot-password-ip", client_ip)
    user = next((u for u in db.query(User).filter(User.business_id == biz.id).all() if normalize_username(u.username) == normalize_username(username)), None)
    if not user or user.disabled or user.email.strip().casefold() != email.casefold():
        record_failure(db, "forgot-password", key)
        record_failure(db, "forgot-password-ip", client_ip)
        raise HTTPException(status_code=400, detail="We could not verify those recovery details.")
    now = datetime.utcnow()
    active_recovery = (db.query(PasswordRecovery).filter(
        PasswordRecovery.user_id == user.id, PasswordRecovery.used == False,
        PasswordRecovery.expires_at > now
    ).order_by(PasswordRecovery.created_at.desc()).first())
    if active_recovery and active_recovery.resend_after > now:
        seconds = max(1, int((active_recovery.resend_after - now).total_seconds()))
        raise HTTPException(status_code=429, detail=f"Please wait {seconds} seconds before requesting another recovery code.")
    # A replacement code invalidates every existing usable recovery code.
    db.query(PasswordRecovery).filter(
        PasswordRecovery.user_id == user.id, PasswordRecovery.used == False,
        PasswordRecovery.expires_at > now,
    ).update({PasswordRecovery.used: True}, synchronize_session=False)
    code = f"{secrets.randbelow(1000000):06d}"
    recovery_id = secrets.token_urlsafe(18)
    row = PasswordRecovery(
        recovery_id=recovery_id, user_id=user.id, channel=channel,
        code_hash=hash_text(code), expires_at=now + timedelta(seconds=FORGOT_CODE_TTL_SECONDS),
        resend_after=now + timedelta(seconds=FORGOT_RESEND_SECONDS)
    )
    # Persist the recovery record only after delivery is accepted by the provider.
    if channel == "email":
        send_recovery_email(user.email, user.username, code)
    else:
        send_recovery_sms(normalize_phone(user.phone), code)
    db.add(row); db.commit()
    clear_failures(db, "forgot-password", key)
    clear_failures(db, "forgot-password-ip", client_ip)
    return {"recovery_id": recovery_id, "channel": channel, "expires_in_seconds": FORGOT_CODE_TTL_SECONDS, "resend_after_seconds": FORGOT_RESEND_SECONDS}

@app.post("/auth/reset-password")
def reset_password(payload: PasswordResetRequest, db: Session = Depends(get_db)):
    recovery_id = payload.recovery_id
    code = payload.code
    new_password = payload.new_password
    validate_password_strength(new_password)
    row = db.query(PasswordRecovery).filter(PasswordRecovery.recovery_id == recovery_id, PasswordRecovery.used == False).first()
    if not row or row.expires_at < datetime.utcnow():
        raise HTTPException(status_code=400, detail="This recovery code has expired. Please request a new code.")
    row.attempts += 1
    if row.attempts > 5:
        row.used = True; db.commit()
        raise HTTPException(status_code=400, detail="Too many recovery attempts. Please request a new code.")
    if hash_text(code) != row.code_hash:
        db.commit(); raise HTTPException(status_code=400, detail="The recovery code is incorrect.")
    user = db.query(User).filter(User.id == row.user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="The account could not be recovered.")
    if user.disabled:
        raise HTTPException(status_code=403, detail="This account is disabled. Please contact your business Admin.")
    if user.previous_password_hash and verify_password(new_password, user.previous_password_hash):
        raise HTTPException(status_code=400, detail="Last created password cannot be used.")
    user.previous_password_hash = user.password
    user.password = hash_password(new_password)
    user.must_change_password = False
    revoke_all_user_sessions(db, user)
    row.used = True
    add_audit(db, user, "PASSWORD_RECOVERED", "Password recovered through the account recovery flow.")
    db.commit()
    return {"message": "Password reset successfully. You can now sign in with your new password."}

# -----------------------------------------------------------------------------
# BUSINESS PROFILE
# -----------------------------------------------------------------------------
@app.get("/business-profile/", response_model=BusinessProfileSchema)
def get_business_profile(user: User = Depends(get_authenticated_user), db: Session = Depends(get_db)):
    biz = db.query(BusinessProfile).filter(BusinessProfile.id == user.business_id).first()
    if not biz: raise HTTPException(status_code=404, detail="Business profile is unavailable.")
    return BusinessProfileSchema(**serialize_business(biz))

@app.post("/business-profile/", response_model=BusinessProfileSchema)
def update_business_profile(profile_data: BusinessProfileSchema, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if user.role != "admin": raise HTTPException(status_code=403, detail="Only Admins can modify Business Profile settings.")
    biz = db.query(BusinessProfile).filter(BusinessProfile.id == user.business_id).first()
    if not biz: raise HTTPException(status_code=404, detail="Business profile is unavailable.")
    country_values = canonical_business_country_values(profile_data.country, profile_data.country_code, profile_data.language)
    biz.company_name = profile_data.company_name
    biz.email = profile_data.email
    biz.phone = canonical_phone_for_country(profile_data.phone, country_values["phone_country_code"])
    biz.address = profile_data.address
    biz.tax_id = profile_data.tax_id
    biz.country = country_values["country"]
    biz.country_code = country_values["country_code"]
    biz.currency = country_values["currency"]
    biz.phone_country_code = country_values["phone_country_code"]
    biz.language = str(profile_data.language or "en").strip().lower() or "en"
    biz.locale = f"{biz.language}-{biz.country_code}"
    biz.timezone = country_values["timezone"]
    add_audit(db, user, "BUSINESS_PROFILE_UPDATED", "Business profile settings were updated.")
    db.commit(); db.refresh(biz)
    return BusinessProfileSchema(**serialize_business(biz))

# -----------------------------------------------------------------------------
# USERS / ACCOUNT MANAGEMENT
# -----------------------------------------------------------------------------
@app.delete("/business-profile/")
def delete_business_profile(response: Response, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if user.role != "admin":
        raise HTTPException(status_code=403, detail="Only the business Admin can delete the business profile.")
    biz = db.query(BusinessProfile).filter(BusinessProfile.id == user.business_id).first()
    if not biz:
        raise HTTPException(status_code=404, detail="Business profile not found.")
    business_id = biz.id
    # Older SQLite files can predate the database-level ON DELETE rules. Remove
    # business-owned rows in dependency order so closure works for both legacy
    # and new databases, rather than relying on an incomplete schema migration.
    upload_rows = db.query(StoredUpload).filter(StoredUpload.business_id == business_id).all()
    upload_paths = [(UPLOAD_STORAGE_DIR / row.storage_key).resolve() for row in upload_rows]
    user_ids = [row[0] for row in db.query(User.id).filter(User.business_id == business_id).all()]
    alert_ids = db.query(Alert.id).filter(Alert.business_id == business_id)
    source_ids = db.query(PriceMonitorSource.id).filter(PriceMonitorSource.business_id == business_id)

    db.query(AlertRead).filter(AlertRead.alert_id.in_(alert_ids)).delete(synchronize_session=False)
    db.query(PriceHistory).filter(PriceHistory.source_id.in_(source_ids)).delete(synchronize_session=False)
    for model in (
        ProductDeletionRequest, AccountActionRequest, AuditLog, SaleModel,
        WarehouseStock, PriceMonitorSource, PurchaseOrder, Product, Supplier,
        PresenceSession, RefreshSession, StoredUpload, BusinessDay, Alert, Warehouse,
    ):
        db.query(model).filter(model.business_id == business_id).delete(synchronize_session=False)
    if user_ids:
        db.query(SessionRevocation).filter(SessionRevocation.user_id.in_(user_ids)).delete(synchronize_session=False)
        db.query(PasswordRecovery).filter(PasswordRecovery.user_id.in_(user_ids)).delete(synchronize_session=False)
        db.query(PresenceSession).filter(PresenceSession.user_id.in_(user_ids)).delete(synchronize_session=False)
        db.query(User).filter(User.id.in_(user_ids)).delete(synchronize_session=False)
    db.delete(biz)
    db.commit()
    for path in upload_paths:
        if UPLOAD_STORAGE_DIR in path.parents:
            path.unlink(missing_ok=True)
    clear_refresh_cookie(response)
    return {"message": "Business profile deleted successfully."}

@app.post("/auth/clear-client-session")
def clear_client_session(response: Response):
    """Clear only the browser's Cauldra refresh cookie. No business or session row is deleted."""
    clear_refresh_cookie(response)
    return {"message": "Client session cookie cleared."}

@app.get("/users")
def list_users(limit: int = Query(50, ge=1, le=200), offset: int = Query(0, ge=0), user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if user.role not in {"admin", "manager"}: raise HTTPException(status_code=403, detail="Access denied")
    q = db.query(User).filter(User.business_id == user.business_id)
    if user.role == "manager": q = q.filter(User.role == "staff")
    users = q.order_by(User.id.asc()).offset(offset).limit(limit).all()
    return [serialize_user(u) for u in users]

@app.post("/users")
def create_user(data: CreateUserRequest, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if user.role not in {"admin", "manager"}: raise HTTPException(status_code=403, detail="Your account is not allowed to create employee accounts.")
    role = data.role.casefold()
    if role not in {"admin","manager","staff"}: raise HTTPException(status_code=400, detail="Unsupported account role.")
    if user.role == "manager" and role != "staff": raise HTTPException(status_code=403, detail="Managers can only create Staff accounts.")
    business = db.query(BusinessProfile).filter(BusinessProfile.id == user.business_id).first()
    current = db.query(User).filter(User.business_id == user.business_id, User.role == role).count()
    check_plan_limit(db, business, role, current)
    validate_password_strength(data.password)
    if normalize_username(data.username) == normalize_username(user.username):
        raise HTTPException(status_code=409, detail="That username is already in use in this business.")
    exists = next((u for u in db.query(User).filter(User.business_id == user.business_id).all() if normalize_username(u.username) == normalize_username(data.username)), None)
    if exists: raise HTTPException(status_code=409, detail="That username is already in use in this business.")
    new_user = User(
        username=data.username.strip(), password=hash_password(data.password), role=role,
        firstname=data.firstname, lastname=data.lastname, email=str(data.email), phone=data.phone, position=data.position,
        business_id=user.business_id, must_change_password=True, disabled=False, auth_version=1,
    )
    db.add(new_user); db.flush()
    add_audit(db, user, "USER_CREATED", f"Created {role} account.", new_user)
    db.commit(); db.refresh(new_user)
    # The creator already supplied the temporary password; never echo it back
    # from the API where it could be retained in logs or browser tooling.
    return serialize_user(new_user)

@app.patch("/users/{user_id}/disable")
def disable_user(user_id: int, actor: User = Depends(get_current_user), db: Session = Depends(get_db)):
    target = db.query(User).filter(User.id == user_id, User.business_id == actor.business_id).first()
    if not target: raise HTTPException(status_code=404, detail="Account is unavailable.")
    if actor.role != "admin": raise HTTPException(status_code=403, detail="Only Admins can disable accounts directly.")
    if target.id == actor.id and target.role == "admin": raise HTTPException(status_code=400, detail="The active business owner account cannot be disabled here.")
    if target.role == "admin" and len(db.query(User).filter(User.business_id == actor.business_id, User.role == "admin", User.disabled == False).all()) <= 1:
        raise HTTPException(status_code=400, detail="The last active Admin cannot be disabled.")
    target.disabled = True
    revoke_all_user_sessions(db, target)
    add_audit(db, actor, "USER_DISABLED", "Account disabled.", target)
    db.commit()
    return {"message": "Account disabled successfully."}

@app.patch("/users/{user_id}/enable")
def enable_user(user_id: int, actor: User = Depends(get_current_user), db: Session = Depends(get_db)):
    target = db.query(User).filter(User.id == user_id, User.business_id == actor.business_id).first()
    if not target: raise HTTPException(status_code=404, detail="Account is unavailable.")
    if actor.role != "admin": raise HTTPException(status_code=403, detail="Only Admins can enable accounts directly.")
    target.disabled = False
    target.auth_version = int(target.auth_version or 1) + 1
    add_audit(db, actor, "USER_ENABLED", "Account enabled.", target)
    db.commit()
    return {"message": "Account enabled successfully."}

@app.patch("/users/{user_id}/reset-password")
def reset_user_password(user_id: int, data: AdminPasswordResetRequest, actor: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if actor.role not in {"admin", "manager"}: raise HTTPException(status_code=403, detail="Access denied.")
    target = db.query(User).filter(User.id == user_id, User.business_id == actor.business_id).first()
    if not target: raise HTTPException(status_code=404, detail="Account is unavailable.")
    if actor.role == "manager" and target.role != "staff": raise HTTPException(status_code=403, detail="Managers can only reset Staff accounts.")
    validate_password_strength(data.new_password)
    if target.previous_password_hash and verify_password(data.new_password, target.previous_password_hash):
        raise HTTPException(status_code=400, detail="Last created password cannot be used.")
    target.previous_password_hash = target.password
    target.password = hash_password(data.new_password)
    target.must_change_password = True
    revoke_all_user_sessions(db, target)
    target.disabled = False
    add_audit(db, actor, "PASSWORD_RESET", "Temporary password reset by authorized staff.", target)
    db.commit()
    return {"message": "Temporary password reset. The employee must change it at next sign-in."}

@app.delete("/users/{user_id}")
def delete_user(user_id: int, actor: User = Depends(get_current_user), db: Session = Depends(get_db)):
    target = db.query(User).filter(User.id == user_id, User.business_id == actor.business_id).first()
    if not target: raise HTTPException(status_code=404, detail="Account is unavailable.")
    if actor.role != "admin": raise HTTPException(status_code=403, detail="Only Admins can delete accounts directly.")
    if target.role == "admin":
        admins = db.query(User).filter(User.business_id == actor.business_id, User.role == "admin", User.disabled == False).count()
        if target.id == actor.id or admins <= 1: raise HTTPException(status_code=400, detail="The last active Admin cannot be deleted.")
    add_audit(db, actor, "USER_DELETED", "Account deleted. Business-owned records were retained.", target)
    db.delete(target); db.commit()
    return {"message": "Account deleted. Business data was preserved."}

# -----------------------------------------------------------------------------
# ACCOUNT ACTION REQUESTS + AUDIT LOGS
# -----------------------------------------------------------------------------
@app.post("/account-action-requests")
def create_account_action_request(data: AccountActionRequestCreate, actor: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if actor.role != "manager": raise HTTPException(status_code=403, detail="Only Managers submit these approval requests.")
    if data.action not in {"delete", "disable"}: raise HTTPException(status_code=400, detail="Unsupported account action.")
    target = db.query(User).filter(User.id == data.target_user_id, User.business_id == actor.business_id).first()
    if not target or target.role != "staff": raise HTTPException(status_code=403, detail="Managers may request actions only for Staff accounts.")
    row = AccountActionRequest(business_id=actor.business_id, target_user_id=target.id, target_username=target.username, action=data.action, requested_by_id=actor.id, requested_by_name=actor.username)
    db.add(row); add_audit(db, actor, "ACCOUNT_ACTION_REQUESTED", f"Requested Admin approval to {data.action} Staff account.", target); db.commit(); db.refresh(row)
    return {"id": row.id, "message": "Admin approval request sent."}

@app.get("/account-action-requests")
def list_account_action_requests(actor: User = Depends(get_current_user), db: Session = Depends(get_db)):
    q = db.query(AccountActionRequest).filter(AccountActionRequest.business_id == actor.business_id, AccountActionRequest.status == "PENDING")
    if actor.role == "manager": q = q.filter(AccountActionRequest.requested_by_id == actor.id)
    elif actor.role != "admin": raise HTTPException(status_code=403, detail="Access denied")
    items = q.order_by(AccountActionRequest.created_at.desc()).all()
    return [{"id": x.id, "target_username": x.target_username, "action": x.action, "requested_by_name": x.requested_by_name, "created_at": x.created_at.isoformat()} for x in items]

@app.post("/account-action-requests/{request_id}/{resolution}")
def resolve_account_action_request(request_id: int, resolution: str, actor: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if actor.role != "admin": raise HTTPException(status_code=403, detail="Only Admins can resolve approval requests.")
    row = db.query(AccountActionRequest).filter(AccountActionRequest.id == request_id, AccountActionRequest.business_id == actor.business_id, AccountActionRequest.status == "PENDING").first()
    if not row: raise HTTPException(status_code=404, detail="Approval request is no longer pending.")
    target = db.query(User).filter(User.id == row.target_user_id, User.business_id == actor.business_id).first() if row.target_user_id else None
    row.status = "APPROVED" if resolution == "approve" else "REJECTED"; row.resolved_by_id = actor.id; row.resolved_at = datetime.utcnow()
    if resolution == "approve" and target:
        if row.action == "disable":
            target.disabled = True
            revoke_all_user_sessions(db, target)
        elif row.action == "delete": db.delete(target)
    add_audit(db, actor, f"ACCOUNT_REQUEST_{row.status}", f"Admin {row.status.lower()} request to {row.action} account.", target)
    db.commit()
    return {"message": f"Request {row.status.lower()}."}

@app.get("/audit-logs")
def list_audit_logs(limit: int = Query(100, ge=1, le=300), offset: int = Query(0, ge=0), actor: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if actor.role not in {"admin", "manager"}: raise HTTPException(status_code=403, detail="Access denied")
    rows = db.query(AuditLog).filter(AuditLog.business_id == actor.business_id).order_by(AuditLog.created_at.desc()).offset(offset).limit(limit).all()
    return [{"id": r.id, "actor_username": r.actor_username, "actor_role": r.actor_role, "action": r.action, "target_username": r.target_username, "description": r.description, "created_at": r.created_at.isoformat()} for r in rows]

def get_warehouse_for_business(db: Session, business_id: int, name: str, active_only: bool = True) -> Optional[Warehouse]:
    cleaned = (name or "").strip()
    if not cleaned:
        return None
    q = db.query(Warehouse).filter(Warehouse.business_id == business_id, func.lower(Warehouse.name) == cleaned.casefold())
    if active_only:
        q = q.filter(Warehouse.is_active == True)
    return q.first()

def serialize_warehouse(w: Warehouse, db: Session) -> dict:
    sku_count = db.query(WarehouseStock.product_id).filter(WarehouseStock.business_id == w.business_id, WarehouseStock.warehouse == w.name).distinct().count()
    return {"id": w.id, "name": w.name, "is_active": w.is_active, "sku_count": sku_count, "created_at": w.created_at.isoformat() if w.created_at else None}

@app.get("/warehouses/")
def list_warehouses(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    rows = db.query(Warehouse).filter(Warehouse.business_id == user.business_id, Warehouse.is_active == True).order_by(Warehouse.name.asc()).all()
    return [serialize_warehouse(w, db) for w in rows]

@app.post("/warehouses/")
def create_warehouse(data: WarehouseCreate, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if user.role not in {"admin", "manager"}:
        raise HTTPException(status_code=403, detail="Only Admins and Managers can create warehouses.")
    name = data.name.strip()
    if len(name) < 2:
        raise HTTPException(status_code=400, detail="Warehouse name must contain at least 2 characters.")
    existing = db.query(Warehouse).filter(Warehouse.business_id == user.business_id, func.lower(Warehouse.name) == name.casefold()).first()
    if existing:
        if not existing.is_active:
            business = db.query(BusinessProfile).filter(BusinessProfile.id == user.business_id).first()
            check_plan_limit(db, business, "warehouse", db.query(Warehouse).filter(Warehouse.business_id == user.business_id, Warehouse.is_active == True).count())
            existing.is_active = True
            existing.updated_at = datetime.utcnow()
            db.commit(); db.refresh(existing)
            return serialize_warehouse(existing, db)
        raise HTTPException(status_code=409, detail="That warehouse already exists in this business.")
    business = db.query(BusinessProfile).filter(BusinessProfile.id == user.business_id).first()
    check_plan_limit(db, business, "warehouse", db.query(Warehouse).filter(Warehouse.business_id == user.business_id, Warehouse.is_active == True).count())
    row = Warehouse(business_id=user.business_id, name=name, is_active=True)
    db.add(row)
    add_audit(db, user, "WAREHOUSE_CREATED", f"Created warehouse {name}.")
    db.commit(); db.refresh(row)
    return serialize_warehouse(row, db)

@app.patch("/warehouses/{warehouse_id}")
def update_warehouse(warehouse_id: int, data: WarehouseUpdate, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if user.role not in {"admin", "manager"}:
        raise HTTPException(status_code=403, detail="Only Admins and Managers can update warehouses.")
    row = db.query(Warehouse).filter(Warehouse.id == warehouse_id, Warehouse.business_id == user.business_id).first()
    if not row:
        raise HTTPException(status_code=404, detail="Warehouse not found.")
    new_name = data.name.strip()
    if len(new_name) < 2:
        raise HTTPException(status_code=400, detail="Warehouse name must contain at least 2 characters.")
    duplicate = db.query(Warehouse).filter(Warehouse.business_id == user.business_id, Warehouse.id != row.id, func.lower(Warehouse.name) == new_name.casefold()).first()
    if duplicate:
        raise HTTPException(status_code=409, detail="That warehouse already exists in this business.")
    old_name = row.name
    if old_name != new_name:
        db.query(Product).filter(Product.business_id == user.business_id, Product.warehouse == old_name).update({Product.warehouse: new_name}, synchronize_session=False)
        db.query(WarehouseStock).filter(WarehouseStock.business_id == user.business_id, WarehouseStock.warehouse == old_name).update({WarehouseStock.warehouse: new_name}, synchronize_session=False)
        row.name = new_name
    if data.is_active is not None:
        row.is_active = bool(data.is_active)
    row.updated_at = datetime.utcnow()
    add_audit(db, user, "WAREHOUSE_UPDATED", f"Updated warehouse {old_name} to {new_name}.")
    db.commit(); db.refresh(row)
    return serialize_warehouse(row, db)

@app.delete("/warehouses/{warehouse_id}")
def deactivate_warehouse(warehouse_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if user.role not in {"admin", "manager"}:
        raise HTTPException(status_code=403, detail="Only Admins and Managers can deactivate warehouses.")
    row = db.query(Warehouse).filter(Warehouse.id == warehouse_id, Warehouse.business_id == user.business_id).first()
    if not row:
        raise HTTPException(status_code=404, detail="Warehouse not found.")
    active_count = db.query(Warehouse).filter(Warehouse.business_id == user.business_id, Warehouse.is_active == True).count()
    if active_count <= 1 and row.is_active:
        raise HTTPException(status_code=400, detail="The last active warehouse cannot be deactivated.")
    row.is_active = False
    row.updated_at = datetime.utcnow()
    add_audit(db, user, "WAREHOUSE_DEACTIVATED", f"Deactivated warehouse {row.name}.")
    db.commit()
    return {"message": "Warehouse deactivated successfully."}

# -----------------------------------------------------------------------------
# PRODUCTS
# -----------------------------------------------------------------------------
def generate_unique_sku(db: Session, business_id: int) -> str:
    for _ in range(50):
        sku = f"SKU-{random.randint(100000, 999999)}"
        if not db.query(Product).filter(Product.business_id == business_id, Product.sku == sku).first():
            return sku
    raise HTTPException(status_code=500, detail="We could not generate a unique SKU. Please try again.")

@app.get("/products/")
def list_products(limit: int = Query(200, ge=1, le=500), offset: int = Query(0, ge=0), warehouse: Optional[str] = Query(None), stock_status: Optional[str] = Query(None, alias="status"), user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    warehouse_name = None
    if warehouse and warehouse.upper() != "ALL":
        wh = get_warehouse_for_business(db, user.business_id, warehouse)
        if not wh:
            raise HTTPException(status_code=404, detail="The selected warehouse is unavailable.")
        warehouse_name = wh.name

    status_value = (stock_status or "").strip().lower()
    if status_value not in {"", "healthy", "low", "out"}:
        raise HTTPException(status_code=400, detail="Invalid stock status filter.")

    if warehouse_name:
        q = (db.query(Product, WarehouseStock.quantity.label("warehouse_quantity"))
             .join(WarehouseStock, and_(WarehouseStock.product_id == Product.id, WarehouseStock.business_id == user.business_id, WarehouseStock.warehouse == warehouse_name))
             .filter(Product.business_id == user.business_id))
        effective_qty = WarehouseStock.quantity
    else:
        q = db.query(Product).filter(Product.business_id == user.business_id)
        effective_qty = Product.quantity

    if status_value == "healthy":
        q = q.filter(effective_qty > Product.min_stock_level)
    elif status_value == "low":
        q = q.filter(effective_qty > 0, effective_qty <= Product.min_stock_level)
    elif status_value == "out":
        q = q.filter(effective_qty == 0)

    q = q.order_by(Product.id.desc()).offset(offset).limit(limit).all()
    rows = []
    if warehouse_name:
        for p, warehouse_quantity in q:
            rows.append({
                "id": p.id, "sku": p.sku, "barcode": p.barcode, "name": p.name, "category": p.category, "size": p.size, "quantity": int(warehouse_quantity or 0),
                "total_quantity": p.quantity, "min_stock_level": p.min_stock_level, "cost_price": p.cost_price, "wholesale_price": p.wholesale_price,
                "retail_price": p.retail_price, "warehouse": warehouse_name, "created_at": p.created_at.isoformat() if p.created_at else None,
                "expiry_date": p.expiry_date.isoformat() if p.expiry_date else None
            })
    else:
        for p in q:
            rows.append({
                "id": p.id, "sku": p.sku, "barcode": p.barcode, "name": p.name, "category": p.category, "size": p.size, "quantity": p.quantity,
                "total_quantity": p.quantity, "min_stock_level": p.min_stock_level, "cost_price": p.cost_price, "wholesale_price": p.wholesale_price,
                "retail_price": p.retail_price, "warehouse": p.warehouse, "created_at": p.created_at.isoformat() if p.created_at else None,
                "expiry_date": p.expiry_date.isoformat() if p.expiry_date else None
            })
    return rows

@app.get("/products/inventory-summary")
def inventory_summary(warehouse: Optional[str] = Query(None), user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    warehouse_name = None
    if warehouse and warehouse.upper() != "ALL":
        wh = get_warehouse_for_business(db, user.business_id, warehouse)
        if not wh:
            raise HTTPException(status_code=404, detail="The selected warehouse is unavailable.")
        warehouse_name = wh.name

    if warehouse_name:
        rows = (db.query(Product.min_stock_level, WarehouseStock.quantity)
                .join(WarehouseStock, and_(WarehouseStock.product_id == Product.id, WarehouseStock.business_id == user.business_id, WarehouseStock.warehouse == warehouse_name))
                .filter(Product.business_id == user.business_id).all())
        quantities = [(int(qty or 0), int(min_level or 0)) for min_level, qty in rows]
    else:
        rows = db.query(Product.quantity, Product.min_stock_level).filter(Product.business_id == user.business_id).all()
        quantities = [(int(qty or 0), int(min_level or 0)) for qty, min_level in rows]

    return {
        "total_products": len(quantities),
        "healthy": sum(1 for qty, minimum in quantities if qty > minimum),
        "low": sum(1 for qty, minimum in quantities if qty > 0 and qty <= minimum),
        "out": sum(1 for qty, minimum in quantities if qty == 0),
    }

@app.post("/products/")
def create_product(data: ProductCreate, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if user.role == "staff": raise HTTPException(status_code=403, detail="Staff accounts cannot add products.")
    business = db.query(BusinessProfile).filter(BusinessProfile.id == user.business_id).first()
    check_plan_limit(db, business, "product", db.query(Product).filter(Product.business_id == user.business_id).count())
    sku=(data.sku or "").strip()
    if not sku:
        for _ in range(50):
            candidate=f"SKU-{random.randint(100000,999999)}"
            if not db.query(Product).filter(Product.business_id==user.business_id, Product.sku==candidate).first(): sku=candidate; break
        if not sku: raise HTTPException(status_code=500, detail="We could not create a unique product code. Please try again.")
    elif db.query(Product).filter(Product.business_id==user.business_id, Product.sku==sku).first():
        raise HTTPException(status_code=409, detail="That SKU is already used in this business.")
    warehouse_name = (data.warehouse or "Main Central Warehouse").strip()
    if not get_warehouse_for_business(db, user.business_id, warehouse_name):
        raise HTTPException(status_code=400, detail="The selected warehouse does not exist in this business.")
    p=Product(sku=sku, barcode=(data.barcode or None), name=data.name, category=data.category, size=data.size, quantity=data.quantity, min_stock_level=data.min_stock_level, cost_price=data.cost_price, wholesale_price=data.wholesale_price or data.retail_price*0.85, retail_price=data.retail_price, warehouse=warehouse_name, initial_stock=data.quantity, expiry_date=data.expiry_date, business_id=user.business_id, owner_id=user.id)
    db.add(p); db.flush(); db.add(WarehouseStock(business_id=user.business_id,product_id=p.id,warehouse=p.warehouse,quantity=p.quantity)); auto_upsert_general_catalog(db,p); add_audit(db,user,"PRODUCT_CREATED",f"Added product {p.name}."); db.commit(); db.refresh(p)
    return {"id":p.id,"sku":p.sku,"barcode":p.barcode,"name":p.name}

@app.patch("/products/{product_id}")
def update_product(product_id: int, data: ProductUpdate, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if user.role == "staff": raise HTTPException(status_code=403, detail="Staff accounts cannot edit products.")
    p = db.query(Product).filter(Product.id == product_id, Product.business_id == user.business_id).first()
    if not p: raise HTTPException(status_code=404, detail="The product could not be found in this inventory.")
    changes = data.model_dump(exclude_unset=True)
    if "sku" in changes and changes["sku"] and changes["sku"] != p.sku:
        if db.query(Product).filter(Product.business_id == user.business_id, Product.sku == changes["sku"], Product.id != p.id).first():
            raise HTTPException(status_code=409, detail="That SKU is already in use in this business.")
    if "warehouse" in changes:
        requested_warehouse = (changes["warehouse"] or "").strip()
        warehouse = get_warehouse_for_business(db, user.business_id, requested_warehouse)
        if not warehouse:
            raise HTTPException(status_code=400, detail="The selected warehouse does not exist in this business.")
        changes["warehouse"] = warehouse.name

    # Product.quantity is the total of its warehouse ledger. Keep direct edits
    # compatible with the existing form while applying the difference to the
    # selected warehouse row, so inventory cannot silently drift out of sync.
    if "quantity" in changes:
        target_warehouse = changes.get("warehouse") or p.warehouse or "Main Central Warehouse"
        stock = db.query(WarehouseStock).filter(
            WarehouseStock.business_id == user.business_id,
            WarehouseStock.product_id == p.id,
            WarehouseStock.warehouse == target_warehouse,
        ).first()
        if not stock:
            stock = WarehouseStock(
                business_id=user.business_id, product_id=p.id,
                warehouse=target_warehouse, quantity=0,
            )
            db.add(stock)
            db.flush()
        other_total = sum(
            int(row.quantity or 0) for row in db.query(WarehouseStock).filter(
                WarehouseStock.business_id == user.business_id,
                WarehouseStock.product_id == p.id,
                WarehouseStock.warehouse != target_warehouse,
            ).all()
        )
        new_stock_quantity = changes["quantity"] - other_total
        if new_stock_quantity < 0:
            raise HTTPException(
                status_code=400,
                detail="Total quantity cannot be lower than stock held in the other warehouses.",
            )
        stock.quantity = new_stock_quantity
    for k, v in changes.items():
        setattr(p, k, v)
    if "quantity" in changes:
        p.quantity = sum(
            int(row.quantity or 0) for row in db.query(WarehouseStock).filter(
                WarehouseStock.business_id == user.business_id,
                WarehouseStock.product_id == p.id,
            ).all()
        )
    auto_upsert_general_catalog(db, p)
    add_audit(db, user, "PRODUCT_UPDATED", f"Updated product {p.name} ({p.sku}).")
    db.commit()
    return {"message": "Product updated successfully."}

@app.delete("/products/{product_id}")
def delete_product(product_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    p = db.query(Product).filter(Product.id == product_id, Product.business_id == user.business_id).first()
    if not p: raise HTTPException(status_code=404, detail="The product could not be found in this inventory.")
    if user.role == "staff": raise HTTPException(status_code=403, detail="Staff accounts cannot delete products.")
    if user.role == "manager":
        row = ProductDeletionRequest(business_id=user.business_id, product_id=p.id, product_name=p.name, requested_by_id=user.id, requested_by_name=user.username)
        db.add(row); add_audit(db, user, "PRODUCT_DELETE_REQUESTED", f"Requested Admin approval to delete product {p.name}.")
        db.commit(); return {"message": "Admin approval request sent."}
    add_audit(db, user, "PRODUCT_DELETED", f"Deleted product {p.name} ({p.sku}).")
    db.delete(p); db.commit(); return {"message": "Product deleted successfully."}

@app.get("/product-deletion-requests")
def list_product_deletion_requests(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if user.role != "admin": raise HTTPException(status_code=403, detail="Access denied")
    rows = db.query(ProductDeletionRequest).filter(ProductDeletionRequest.business_id == user.business_id, ProductDeletionRequest.status == "PENDING").all()
    return [{"id": r.id, "product_name": r.product_name, "sku": (db.query(Product).filter(Product.id == r.product_id).first().sku if r.product_id and db.query(Product).filter(Product.id == r.product_id).first() else ""), "requested_by_name": r.requested_by_name} for r in rows]

@app.post("/product-deletion-requests/{request_id}/{resolution}")
def resolve_product_deletion(request_id: int, resolution: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if user.role != "admin": raise HTTPException(status_code=403, detail="Only Admins can resolve deletion requests.")
    row = db.query(ProductDeletionRequest).filter(ProductDeletionRequest.id == request_id, ProductDeletionRequest.business_id == user.business_id, ProductDeletionRequest.status == "PENDING").first()
    if not row: raise HTTPException(status_code=404, detail="Deletion request is no longer pending.")
    product = db.query(Product).filter(Product.id == row.product_id, Product.business_id == user.business_id).first() if row.product_id else None
    row.status = "APPROVED" if resolution == "approve" else "REJECTED"; row.resolved_by_id = user.id; row.resolved_by_name = user.username; row.resolved_at = datetime.utcnow()
    if resolution == "approve" and product:
        add_audit(db, user, "PRODUCT_DELETED", f"Approved and deleted product {product.name}.")
        db.delete(product)
    else:
        add_audit(db, user, "PRODUCT_DELETE_REQUEST_REJECTED", f"Rejected product deletion request for {row.product_name}.")
    db.commit(); return {"message": f"Request {row.status.lower()}."}

@app.patch("/products/{product_id}/stock")
def update_stock(product_id: int, data: StockUpdate, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    p = db.query(Product).filter(Product.id == product_id, Product.business_id == user.business_id).first()
    if not p: raise HTTPException(status_code=404, detail="The product could not be found in this inventory.")
    warehouse_name = p.warehouse or "Main Central Warehouse"
    stock = db.query(WarehouseStock).filter(
        WarehouseStock.business_id == user.business_id,
        WarehouseStock.product_id == p.id,
        WarehouseStock.warehouse == warehouse_name,
    ).first()
    if not stock:
        stock = WarehouseStock(business_id=user.business_id, product_id=p.id, warehouse=warehouse_name, quantity=0)
        db.add(stock)
        db.flush()
    if stock.quantity + data.quantity_change < 0:
        raise HTTPException(status_code=400, detail=f"Stock in {warehouse_name} cannot become negative.")
    stock.quantity += data.quantity_change
    p.quantity = sum(
        int(row.quantity or 0) for row in db.query(WarehouseStock).filter(
            WarehouseStock.business_id == user.business_id, WarehouseStock.product_id == p.id,
        ).all()
    )
    db.commit(); return {"message": "Stock updated successfully.", "quantity": p.quantity}

@app.patch("/products/{product_id}/transfer")
def transfer_stock(product_id: int, data: StockTransfer, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if user.role == "staff": raise HTTPException(status_code=403, detail="Staff accounts cannot transfer stock between warehouses.")
    if data.quantity<1 or data.from_warehouse==data.to_warehouse: raise HTTPException(status_code=400, detail="Choose different warehouses and enter a positive quantity.")
    p=db.query(Product).filter(Product.id==product_id,Product.business_id==user.business_id).first()
    if not p: raise HTTPException(status_code=404, detail="The selected product is unavailable.")
    if not get_warehouse_for_business(db, user.business_id, data.from_warehouse) or not get_warehouse_for_business(db, user.business_id, data.to_warehouse):
        raise HTTPException(status_code=400, detail="Both selected warehouses must be active warehouses in this business.")
    source=db.query(WarehouseStock).filter(WarehouseStock.product_id==p.id,WarehouseStock.warehouse==data.from_warehouse).first()
    if not source:
        if p.warehouse==data.from_warehouse:
            source=WarehouseStock(business_id=user.business_id,product_id=p.id,warehouse=data.from_warehouse,quantity=p.quantity); db.add(source); db.flush()
        else: raise HTTPException(status_code=400, detail="There is no stock recorded in the selected source warehouse.")
    if source.quantity<data.quantity: raise HTTPException(status_code=400, detail=f"Only {source.quantity} units are recorded in {data.from_warehouse}.")
    target=db.query(WarehouseStock).filter(WarehouseStock.product_id==p.id,WarehouseStock.warehouse==data.to_warehouse).first()
    if not target: target=WarehouseStock(business_id=user.business_id,product_id=p.id,warehouse=data.to_warehouse,quantity=0); db.add(target); db.flush()
    source.quantity-=data.quantity; target.quantity+=data.quantity
    p.quantity=sum(w.quantity for w in db.query(WarehouseStock).filter(WarehouseStock.product_id==p.id).all())
    add_audit(db,user,"STOCK_TRANSFER",f"Transferred {data.quantity} units of {p.name} from {data.from_warehouse} to {data.to_warehouse}.")
    db.commit(); return {"message":"Stock transfer completed successfully.","quantity_transferred":data.quantity,"from_warehouse":data.from_warehouse,"to_warehouse":data.to_warehouse,"total_quantity":p.quantity}

@app.get("/products/{product_id}/warehouse-stocks")
def product_warehouse_stocks(product_id:int,user:User=Depends(get_current_user),db:Session=Depends(get_db)):
    p=db.query(Product).filter(Product.id==product_id,Product.business_id==user.business_id).first()
    if not p: raise HTTPException(status_code=404, detail="The selected product is unavailable.")
    rows=db.query(WarehouseStock).filter(WarehouseStock.product_id==p.id,WarehouseStock.business_id==user.business_id).order_by(WarehouseStock.warehouse.asc()).all()
    if not rows:
        row=WarehouseStock(business_id=user.business_id,product_id=p.id,warehouse=p.warehouse or "Main Central Warehouse",quantity=p.quantity); db.add(row); db.commit(); rows=[row]
    return [{"warehouse":r.warehouse,"quantity":r.quantity} for r in rows]

@app.get("/products/predictive-forecast")
def predictive_forecast(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    sales_count = db.query(SaleModel).filter(SaleModel.business_id == user.business_id).count()
    history_days = db.query(BusinessDay).filter(BusinessDay.business_id == user.business_id, BusinessDay.is_open == False).count()
    products = db.query(Product).filter(Product.business_id == user.business_id).all()
    forecast = []
    for p in products:
        product_sales = db.query(func.sum(SaleModel.quantity)).filter(SaleModel.business_id == user.business_id, SaleModel.product_id == p.id).scalar() or 0
        daily_velocity = (product_sales / max(history_days, 1)) if history_days else 0
        days_to_stockout = round(p.quantity / daily_velocity, 1) if daily_velocity > 0 else None
        risk = "unknown"
        if days_to_stockout is not None:
            risk = "critical" if days_to_stockout <= 7 else "moderate" if days_to_stockout <= 21 else "low"
        forecast.append({"name": p.name, "sku": p.sku, "quantity": p.quantity, "daily_velocity": round(daily_velocity, 2), "days_to_stockout": days_to_stockout, "risk": risk})
    return {"report_ready": history_days >= 6, "history_days": history_days, "sales_count": sales_count, "forecast": forecast}

# -----------------------------------------------------------------------------
# SUPPLIERS
# -----------------------------------------------------------------------------
@app.get("/suppliers/")
def list_suppliers(limit: int = Query(200, ge=1, le=500), offset: int = Query(0, ge=0), user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    rows = db.query(Supplier).filter(Supplier.business_id == user.business_id).order_by(Supplier.id.desc()).offset(offset).limit(limit).all()
    return [{"id": s.id, "name": s.name, "contact_email": s.contact_email, "phone": s.phone, "lead_time_days": s.lead_time_days} for s in rows]

@app.post("/suppliers/")
def create_supplier(data: SupplierCreate, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if user.role == "staff": raise HTTPException(status_code=403, detail="Staff accounts cannot add suppliers.")
    business = db.query(BusinessProfile).filter(BusinessProfile.id == user.business_id).first()
    check_plan_limit(db, business, "supplier", db.query(Supplier).filter(Supplier.business_id == user.business_id).count())
    s = Supplier(name=data.name, contact_email=data.contact_email, phone=data.phone, lead_time_days=data.lead_time_days or 3, business_id=user.business_id)
    db.add(s); db.flush(); add_audit(db, user, "SUPPLIER_CREATED", f"Added supplier {s.name}."); db.commit(); db.refresh(s)
    return {"id": s.id, "message": "Supplier added successfully."}

@app.delete("/suppliers/{supplier_id}")
def delete_supplier(supplier_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if user.role == "staff": raise HTTPException(status_code=403, detail="Staff accounts cannot delete suppliers.")
    s = db.query(Supplier).filter(Supplier.id == supplier_id, Supplier.business_id == user.business_id).first()
    if not s: raise HTTPException(status_code=404, detail="The supplier could not be found.")
    add_audit(db, user, "SUPPLIER_DELETED", f"Deleted supplier {s.name}.")
    db.delete(s); db.commit()
    return {"message": "Supplier deleted successfully."}

# -----------------------------------------------------------------------------
# PURCHASE ORDERS
# -----------------------------------------------------------------------------
@app.get("/purchase-orders/")
def get_purchase_orders(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if user.role == "staff": raise HTTPException(status_code=403, detail="Access denied")
    rows = db.query(PurchaseOrder).filter(PurchaseOrder.business_id == user.business_id).order_by(PurchaseOrder.id.desc()).all()
    out=[]
    for po in rows:
        supplier = db.query(Supplier).filter(Supplier.id == po.supplier_id).first() if po.supplier_id else None
        out.append({"id": po.id, "supplier_id": po.supplier_id, "vendor_name": supplier.name if supplier else "General Vendor", "status": po.status, "total_estimated_cost": po.total_estimated_cost, "items_summary": po.email_draft or "", "email_draft": po.email_draft or ""})
    return out

@app.post("/purchase-orders/generate")
def generate_po(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if user.role == "staff": raise HTTPException(status_code=403, detail="Access denied")
    business = db.query(BusinessProfile).filter(BusinessProfile.id == user.business_id).first()
    period_start, period_end, _ = billing_period_for(db, business)
    current = db.query(PurchaseOrder).filter(PurchaseOrder.business_id == user.business_id, PurchaseOrder.created_at >= period_start, PurchaseOrder.created_at < period_end).count()
    check_plan_limit(db, business, "purchase_order", current)
    low_stock = db.query(Product).filter(Product.business_id == user.business_id, Product.quantity <= Product.min_stock_level).all()
    if not low_stock: raise HTTPException(status_code=400, detail="No low stock items requiring restock.")
    total_cost = sum(p.cost_price * max(p.min_stock_level * 2, 1) for p in low_stock)
    items = ", ".join([f"{p.name} ({max(p.min_stock_level * 2, 1)} units)" for p in low_stock])
    draft = f"Please confirm availability for: {items}."
    po = PurchaseOrder(status="DRAFT", total_estimated_cost=total_cost, email_draft=draft, business_id=user.business_id, owner_id=None)
    db.add(po); db.flush(); add_audit(db, user, "PURCHASE_ORDER_CREATED", f"Generated purchase order #{po.id}."); db.commit(); db.refresh(po)
    return {"message": "Purchase Order generated successfully.", "id": po.id, "po_id": po.id}

@app.put("/purchase-orders/{po_id}")
def update_po_draft(po_id: int, update: PODraftUpdate, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if user.role == "staff": raise HTTPException(status_code=403, detail="Access denied")
    po = db.query(PurchaseOrder).filter(PurchaseOrder.id == po_id, PurchaseOrder.business_id == user.business_id).first()
    if not po: raise HTTPException(status_code=404, detail="Purchase order not found.")
    details = update.details if update.details is not None else update.items_summary
    if details is not None: po.email_draft = details
    if update.supplier_id is not None: po.supplier_id = update.supplier_id
    db.commit(); add_audit(db, user, "PURCHASE_ORDER_UPDATED", f"Updated purchase order #{po.id}."); db.commit()
    return {"message": "PO draft updated."}

@app.delete("/purchase-orders/{po_id}")
def delete_po(po_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if user.role == "staff": raise HTTPException(status_code=403, detail="Access denied")
    po = db.query(PurchaseOrder).filter(PurchaseOrder.id == po_id, PurchaseOrder.business_id == user.business_id).first()
    if not po: raise HTTPException(status_code=404, detail="Purchase order not found.")
    add_audit(db, user, "PURCHASE_ORDER_DELETED", f"Deleted purchase order #{po.id}.")
    db.delete(po); db.commit(); return {"message": "Purchase order deleted."}

@app.delete("/purchase-orders")
def delete_all_pos(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if user.role != "admin": raise HTTPException(status_code=403, detail="Only Admins can delete all purchase orders.")
    db.query(PurchaseOrder).filter(PurchaseOrder.business_id == user.business_id).delete(synchronize_session=False)
    add_audit(db, user, "PURCHASE_ORDERS_CLEARED", "Cleared all purchase orders."); db.commit(); return {"message": "All purchase orders deleted."}

@app.post("/purchase-orders/{po_id}/dispatch")
def dispatch_po(po_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if user.role == "staff": raise HTTPException(status_code=403, detail="Access denied")
    po = db.query(PurchaseOrder).filter(PurchaseOrder.id == po_id, PurchaseOrder.business_id == user.business_id).first()
    if not po or not po.supplier_id: raise HTTPException(status_code=400, detail="Purchase order or assigned supplier is unavailable.")
    supplier = db.query(Supplier).filter(Supplier.id == po.supplier_id, Supplier.business_id == user.business_id).first()
    if not supplier: raise HTTPException(status_code=404, detail="Supplier is unavailable.")
    phone = normalize_phone(supplier.phone)
    encoded = urllib.parse.quote(po.email_draft or "")
    po.status = "SENT"; db.commit(); add_audit(db, user, "PURCHASE_ORDER_DISPATCHED", f"Dispatched purchase order #{po.id} via WhatsApp."); db.commit()
    return {"message": f"Purchase Order dispatched to {supplier.name}.", "whatsapp_url": f"https://wa.me/{phone}?text={encoded}"}

@app.post("/purchase-orders/{po_id}/dispatch-email")
def dispatch_po_email(po_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if user.role == "staff": raise HTTPException(status_code=403, detail="Access denied")
    po = db.query(PurchaseOrder).filter(PurchaseOrder.id == po_id, PurchaseOrder.business_id == user.business_id).first()
    if not po or not po.supplier_id: raise HTTPException(status_code=400, detail="Purchase order or assigned supplier is unavailable.")
    supplier = db.query(Supplier).filter(Supplier.id == po.supplier_id, Supplier.business_id == user.business_id).first()
    if not supplier: raise HTTPException(status_code=404, detail="Supplier is unavailable.")
    if not supplier.contact_email: raise HTTPException(status_code=400, detail="This supplier has no contact email on file.")
    api_key = os.getenv("RESEND_API_KEY", "").strip()
    if not api_key:
        raise HTTPException(status_code=503, detail="Email dispatch is not configured. Add RESEND_API_KEY to the server environment.")
    import requests
    try:
        r = requests.post(
            "https://api.resend.com/emails",
            headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
            json={
                "from": RESEND_FROM,
                "to": [supplier.contact_email],
                "subject": f"Purchase Order #{po.id}",
                "html": f"<p>Hello {supplier.name},</p><p>{(po.email_draft or '').replace(chr(10), '<br>')}</p>",
            },
            timeout=15,
        )
        if not r.ok:
            raise RuntimeError(r.text)
    except Exception as exc:
        raise HTTPException(status_code=502, detail="We could not email this purchase order right now.") from exc
    po.status = "SENT"; db.commit(); add_audit(db, user, "PURCHASE_ORDER_DISPATCHED", f"Emailed purchase order #{po.id} to {supplier.name}."); db.commit()
    return {"message": f"Purchase Order emailed to {supplier.name}."}

# -----------------------------------------------------------------------------
# SALES / BUSINESS DAYS
# -----------------------------------------------------------------------------
@app.post("/sales/checkout")
def sales_checkout(payload: SalesCheckoutRequest, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if user.role not in {"admin", "manager", "staff"}: raise HTTPException(status_code=403, detail="Access denied")
    day = ensure_open_business_day(db, user.business_id)
    items = payload.items
    if not items: raise HTTPException(status_code=400, detail="Cart is empty.")
    daily_total = 0.0
    for item in items:
        p = db.query(Product).filter(Product.id == item.product_id, Product.business_id == user.business_id).first()
        qty = item.quantity
        if not p: raise HTTPException(status_code=404, detail="A selected item is no longer in this inventory.")
        price = p.retail_price
        if qty < 1 or qty > p.quantity: raise HTTPException(status_code=400, detail=f"Not enough stock for {p.name}.")
        p.quantity -= qty
        stock=db.query(WarehouseStock).filter(WarehouseStock.product_id==p.id,WarehouseStock.warehouse==(p.warehouse or "Main Central Warehouse")).first()
        if stock: stock.quantity=max(0,stock.quantity-qty)
        total = qty * price
        db.add(SaleModel(business_id=user.business_id, product_id=p.id, quantity=qty, total_price=total, timestamp=datetime.utcnow()))
        daily_total += total
    db.commit()
    add_audit(db, user, "SALE_COMPLETED", f"Completed a sale worth {daily_total:.2f}."); db.commit()
    return {"message": "Sale completed successfully.", "daily_total": daily_total, "business_day_id": day.id}

@app.get("/sales/current-day")
def current_sales_day(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    day = ensure_open_business_day(db, user.business_id)
    rows = db.query(SaleModel).filter(SaleModel.business_id == user.business_id, SaleModel.timestamp >= day.opened_at).all()
    return {"open": day.is_open, "business_day": {"id": day.id, "date": day.date, "opened_at": day.opened_at.isoformat(), "net_sales": sum(r.total_price for r in rows), "transactions": len(rows), "items_sold": sum(r.quantity for r in rows)}}

@app.get("/sales/history")
def sales_history(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if user.role == "staff": raise HTTPException(status_code=403, detail="Access denied")
    days = db.query(BusinessDay).filter(BusinessDay.business_id == user.business_id, BusinessDay.is_open == False).order_by(BusinessDay.date.desc()).all()
    out=[]
    for d in days:
        rows = db.query(SaleModel).filter(SaleModel.business_id == user.business_id, SaleModel.timestamp >= d.opened_at, SaleModel.timestamp <= (d.closed_at or datetime.utcnow())).all()
        out.append({"date": d.date, "transactions": len(rows), "items_sold": sum(r.quantity for r in rows), "net_sales": sum(r.total_price for r in rows)})
    return out

@app.get("/sales/analytics")
def sales_analytics(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    days = db.query(BusinessDay).filter(BusinessDay.business_id == user.business_id, BusinessDay.is_open == False).order_by(BusinessDay.date.asc()).all()
    rows=[]
    for d in days:
        sales = db.query(SaleModel).filter(SaleModel.business_id == user.business_id, SaleModel.timestamp >= d.opened_at, SaleModel.timestamp <= (d.closed_at or datetime.utcnow())).all()
        rows.append({"date": d.date, "sales": sum(s.total_price for s in sales)})
    vals = [r["sales"] for r in rows]
    avg = sum(vals)/len(vals) if vals else 0
    change = 0
    if len(vals) >= 2 and vals[-2]: change = round(((vals[-1]-vals[-2])/vals[-2])*100,1)
    trend = "Growing" if change > 0 else "Declining" if change < 0 else "Stable"
    return {"days": rows, "average_daily_sales": avg, "change_percent": change, "trend": trend}

@app.post("/sales/end-business-day")
def end_business_day(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if user.role == "staff": raise HTTPException(status_code=403, detail="Staff accounts cannot close the business day.")
    day = ensure_open_business_day(db, user.business_id)
    if not day.is_open: return {"message": "Business day is already closed."}
    day.is_open = False; day.closed_at = datetime.utcnow(); add_audit(db, user, "BUSINESS_DAY_CLOSED", f"Closed business day {day.date}."); db.commit(); return {"message": "Business day closed and recorded."}

# -----------------------------------------------------------------------------
# PRESENCE
# -----------------------------------------------------------------------------
@app.post("/presence/heartbeat")
def presence_heartbeat(payload: PresenceHeartbeatRequest, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    session_id = payload.session_id or secrets.token_urlsafe(18)
    row = db.query(PresenceSession).filter(PresenceSession.session_id == session_id, PresenceSession.user_id == user.id).first()
    if not row: row = PresenceSession(session_id=session_id, business_id=user.business_id, user_id=user.id); db.add(row)
    row.last_seen_at = datetime.utcnow(); row.signed_out_at = None; db.commit(); return {"session_id": session_id}

@app.post("/presence/logout")
def presence_logout(payload: PresenceHeartbeatRequest, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    session_id = payload.session_id
    if session_id:
        row = db.query(PresenceSession).filter(PresenceSession.session_id == session_id, PresenceSession.user_id == user.id).first()
        if row: row.signed_out_at = datetime.utcnow(); db.commit()
    return {"message": "Presence session ended."}

@app.get("/presence/team")
def team_presence(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    cutoff = datetime.utcnow() - timedelta(minutes=2)
    rows = db.query(PresenceSession).filter(PresenceSession.business_id == user.business_id, PresenceSession.signed_out_at.is_(None), PresenceSession.last_seen_at >= cutoff).all()
    online=[]
    for row in rows:
        target = db.query(User).filter(User.id == row.user_id).first()
        if target and target.id != user.id:
            online.append({"name": f"{target.firstname or ''} {target.lastname or ''}".strip() or target.username, "role": target.role, "position": target.position, "signed_in_at": row.signed_in_at.isoformat()})
    return {"online": online}

# -----------------------------------------------------------------------------
# ALERTS
# -----------------------------------------------------------------------------
@app.get("/alerts")
def get_alerts(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return format_alerts_for_user(db, user)

@app.post("/alerts/{alert_id}/read")
def read_alert(alert_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if not db.query(Alert).filter(Alert.id == alert_id, Alert.business_id == user.business_id).first(): raise HTTPException(status_code=404, detail="Notification is unavailable.")
    if not db.query(AlertRead).filter(AlertRead.alert_id == alert_id, AlertRead.user_id == user.id).first():
        db.add(AlertRead(alert_id=alert_id, user_id=user.id)); db.commit()
    return {"message": "Notification dismissed."}

# -----------------------------------------------------------------------------
# PRICE MONITOR
# -----------------------------------------------------------------------------
@app.get("/price-monitor")
def price_monitor(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    rows = db.query(PriceMonitorSource).filter(PriceMonitorSource.business_id == user.business_id).order_by(PriceMonitorSource.id.desc()).all()
    sources=[]
    for s in rows:
        product = db.query(Product).filter(Product.id == s.product_id).first() if s.product_id else None
        supplier = db.query(Supplier).filter(Supplier.id == s.supplier_id).first() if s.supplier_id else None
        hist = db.query(PriceHistory).filter(PriceHistory.source_id == s.id).order_by(PriceHistory.recorded_at.asc()).all()
        change = None
        if len(hist) >= 2 and hist[-2].price:
            change = round(((hist[-1].price - hist[-2].price)/hist[-2].price)*100, 2)
        sources.append({"id": s.id, "product_name": product.name if product else "Unknown product", "sku": product.sku if product else "", "supplier_name": supplier.name if supplier else "General Vendor", "source_type": s.source_type, "last_price": s.last_price, "change_percent": change, "history": [{"price": h.price, "recorded_at": h.recorded_at.isoformat()} for h in hist]})
    return {"sources": sources}

@app.post("/price-monitor/sources")
def create_price_source(payload: PriceSourceCreate, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    supplier_id = payload.supplier_id; product_id = payload.product_id; source_type = payload.source_type
    if not db.query(Supplier).filter(Supplier.id == supplier_id, Supplier.business_id == user.business_id).first(): raise HTTPException(status_code=404, detail="Supplier is unavailable.")
    if not db.query(Product).filter(Product.id == product_id, Product.business_id == user.business_id).first(): raise HTTPException(status_code=404, detail="Product is unavailable.")
    business = db.query(BusinessProfile).filter(BusinessProfile.id == user.business_id).first()
    check_plan_limit(db, business, "price_monitor", db.query(PriceMonitorSource).filter(PriceMonitorSource.business_id == user.business_id).count())
    s=PriceMonitorSource(business_id=user.business_id, supplier_id=supplier_id, product_id=product_id, source_type=source_type, source_url=payload.source_url, last_price=payload.initial_price)
    db.add(s); db.commit(); return {"id": s.id, "message": "Price source added."}

@app.post("/price-monitor/{source_id}/price")
def manual_price_update(source_id: int, payload: ManualPriceUpdate, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    s=db.query(PriceMonitorSource).filter(PriceMonitorSource.id == source_id, PriceMonitorSource.business_id == user.business_id).first()
    if not s: raise HTTPException(status_code=404, detail="Price source is unavailable.")
    price=payload.price; s.last_price=price; s.last_checked_at=datetime.utcnow(); db.add(PriceHistory(source_id=s.id, price=price)); db.commit(); return {"message":"Supplier price recorded."}

@app.post("/price-monitor/{source_id}/check")
def check_price_source(source_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    s=db.query(PriceMonitorSource).filter(PriceMonitorSource.id == source_id, PriceMonitorSource.business_id == user.business_id).first()
    if not s: raise HTTPException(status_code=404, detail="Price source is unavailable.")
    if s.source_type != "website": raise HTTPException(status_code=400, detail="Only website monitoring sources can be checked automatically.")
    # Safe behavior until a real website scraper/parser is configured: retain the last price.
    if s.last_price is None: raise HTTPException(status_code=422, detail="No supplier price has been recorded for this source yet.")
    s.last_checked_at=datetime.utcnow(); db.add(PriceHistory(source_id=s.id, price=s.last_price)); db.commit(); return {"message":"Supplier price checked successfully."}

@app.post("/price-monitor/upload-price-list")
def upload_price_list(payload: PriceListUploadRequest, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    # The browser sends a data URL, which is retained privately after validation.
    supplier_id=payload.supplier_id; product_id=payload.product_id
    if not db.query(Supplier).filter(Supplier.id == supplier_id, Supplier.business_id == user.business_id).first():
        raise HTTPException(status_code=404, detail="Supplier is unavailable.")
    if product_id and not db.query(Product).filter(Product.id == product_id, Product.business_id == user.business_id).first():
        raise HTTPException(status_code=404, detail="Product is unavailable.")
    file_name = safe_upload_name(payload.file_name, "price-list.csv")
    if Path(file_name).suffix.lower() != ".csv":
        raise HTTPException(status_code=422, detail="Please upload a CSV price list.")
    raw_bytes, content_type = decode_base64_upload(payload.file_data, {"text/csv", "application/vnd.ms-excel"})
    try:
        raw = raw_bytes.decode("utf-8-sig")
    except Exception as exc:
        raise HTTPException(status_code=422, detail="The price list could not be read.") from exc
    count=0
    for line in raw.splitlines()[1:]:
        parts=[p.strip() for p in line.split(",")]
        if len(parts) < 2: continue
        try: price=float(parts[-1])
        except: continue
        pid=int(product_id) if product_id else (int(parts[0]) if parts[0].isdigit() else None)
        if not pid: continue
        s=db.query(PriceMonitorSource).filter(PriceMonitorSource.business_id == user.business_id, PriceMonitorSource.supplier_id == supplier_id, PriceMonitorSource.product_id == pid).first()
        if not s:
            s=PriceMonitorSource(business_id=user.business_id, supplier_id=supplier_id, product_id=pid, source_type="price_list"); db.add(s); db.flush()
        s.last_price=price; s.last_checked_at=datetime.utcnow(); db.add(PriceHistory(source_id=s.id, price=price)); count += 1
    if not count:
        raise HTTPException(status_code=422, detail="No valid price rows were found in this CSV file.")
    upload = persist_upload(db, user, "price_list", file_name, content_type, raw_bytes)
    add_audit(db, user, "PRICE_LIST_UPLOADED", f"Uploaded and processed price list {upload.original_name}.")
    db.commit(); return {"count": count, "upload_id": upload.id}

# -----------------------------------------------------------------------------
# GENERAL CATALOG + BARCODE
# -----------------------------------------------------------------------------
@app.post("/ai/scan-barcode")
def scan_barcode(req: BarcodeScanRequest, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    barcode = normalize_phone(req.barcode)
    if not barcode: raise HTTPException(status_code=400, detail="Please scan or enter a barcode.")
    item = db.query(GeneralCatalog).filter(GeneralCatalog.barcode == barcode).first()
    if not item:
        return {"product_name": "No matching product was found", "category": "", "manual_entry": True, "barcode": barcode}
    return {"product_name": item.product_name, "category": item.category, "barcode": item.barcode, "manual_entry": False}

@app.get("/general-catalog")
def search_general_catalog(barcode: Optional[str] = None, limit: int = Query(50, ge=1, le=200), offset: int = Query(0, ge=0), user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    q = db.query(GeneralCatalog)
    if barcode: q = q.filter(GeneralCatalog.barcode == normalize_phone(barcode))
    return [{"id": x.id, "barcode": x.barcode, "product_name": x.product_name, "category": x.category, "brand": x.brand} for x in q.order_by(GeneralCatalog.id.desc()).offset(offset).limit(limit).all()]

# -----------------------------------------------------------------------------
# AI
# -----------------------------------------------------------------------------
@app.get("/subscription/usage")
def subscription_usage(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    business = db.query(BusinessProfile).filter(BusinessProfile.id == user.business_id).first()
    summary = usage_summary(db, business)
    plan = subscription_for(db, business)
    period_start, period_end, _ = billing_period_for(db, business)
    storage_used_bytes = db.query(func.coalesce(func.sum(StoredUpload.size_bytes), 0)).filter(StoredUpload.business_id == business.id).scalar() or 0
    po_this_period = db.query(PurchaseOrder).filter(PurchaseOrder.business_id == business.id, PurchaseOrder.created_at >= period_start, PurchaseOrder.created_at < period_end).count()
    role_counts = {role: db.query(User).filter(User.business_id == business.id, User.role == role).count() for role in ("admin", "manager", "staff")}
    resources = {
        "products": db.query(Product).filter(Product.business_id == business.id).count(),
        "suppliers": db.query(Supplier).filter(Supplier.business_id == business.id).count(),
        "warehouses": db.query(Warehouse).filter(Warehouse.business_id == business.id, Warehouse.is_active == True).count(),
        "users": sum(role_counts.values()),
        "price_monitor_sources": db.query(PriceMonitorSource).filter(PriceMonitorSource.business_id == business.id).count(),
        "purchase_orders": po_this_period,
        "storage_bytes": storage_used_bytes,
    }
    total_user_limit = None if all(plan.get(role) is None for role in ("admin", "manager", "staff")) else sum(plan.get(role) or 0 for role in ("admin", "manager", "staff"))
    summary["resources"] = {name: {"used": used, "limit": (total_user_limit if key == "users" else plan.get(key))} for name, used, key in [
        ("products", resources["products"], "product"), ("suppliers", resources["suppliers"], "supplier"), ("warehouses", resources["warehouses"], "warehouse"),
        ("users", resources["users"], "users"), ("price_monitor_sources", resources["price_monitor_sources"], "price_monitor"),
        ("purchase_orders", resources["purchase_orders"], "purchase_order"),
    ]}
    summary["resources"]["storage"] = {"used_gb": round(storage_used_bytes / (1024**3), 3), "limit_gb": plan["storage_gb"]}
    summary["resources"]["users_by_role"] = {role: {"used": role_counts[role], "limit": plan.get(role)} for role in ("admin", "manager", "staff")}
    summary["unlimited_people_and_locations"] = plan.get("admin") is None
    return summary

class ChangePlanRequest(BaseModel):
    plan: str
    billing_interval: Optional[str] = None

@app.post("/subscription/change-plan")
def change_plan(data: ChangePlanRequest, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if user.role != "admin":
        raise HTTPException(status_code=403, detail="Only an Admin can change the subscription plan.")
    plan = str(data.plan or "").strip().lower()
    if plan not in PLAN_CONFIG:
        raise HTTPException(status_code=400, detail="Please choose a valid subscription plan.")
    interval = str(data.billing_interval or "").strip().lower()
    business = db.query(BusinessProfile).filter(BusinessProfile.id == user.business_id).first()
    sub = get_or_create_subscription(db, business)
    if interval not in ("monthly", "annual"):
        interval = sub.billing_interval or "monthly"

    # A downgrade must not silently strip data the business already has — surface
    # it as a clear, actionable error instead of a partial/confusing state.
    new_limits = PLAN_CONFIG[plan]
    role_counts = {role: db.query(User).filter(User.business_id == business.id, User.role == role).count() for role in ("admin", "manager", "staff")}
    checks = [
        ("admin", role_counts["admin"]), ("manager", role_counts["manager"]), ("staff", role_counts["staff"]),
        ("product", db.query(Product).filter(Product.business_id == business.id).count()),
        ("supplier", db.query(Supplier).filter(Supplier.business_id == business.id).count()),
        ("warehouse", db.query(Warehouse).filter(Warehouse.business_id == business.id, Warehouse.is_active == True).count()),
        ("price_monitor", db.query(PriceMonitorSource).filter(PriceMonitorSource.business_id == business.id).count()),
    ]
    for resource, current in checks:
        maximum = new_limits.get(resource)
        if maximum is not None and current > maximum:
            raise HTTPException(status_code=409, detail=f"Your current usage ({current} {resource.replace('_',' ')}) exceeds the {new_limits['label']} limit of {maximum}. Reduce usage before switching to this plan.")

    sub.plan = plan; sub.billing_interval = interval
    business.subscription_plan = plan; business.billing_interval = interval
    add_audit(db, user, "SUBSCRIPTION_PLAN_CHANGED", f"Subscription changed to {new_limits['label']} ({interval}).")
    db.commit()
    return usage_summary(db, business)

class CheckoutRequest(BaseModel):
    plan: str
    billing_interval: str = "monthly"

@app.post("/subscription/checkout")
def start_checkout(data: CheckoutRequest, user: User = Depends(get_authenticated_user), db: Session = Depends(get_db)):
    if user.role != "admin":
        raise HTTPException(status_code=403, detail="Only an Admin can start a subscription payment.")
    plan = str(data.plan or "").strip().lower()
    if plan not in PLAN_CONFIG:
        raise HTTPException(status_code=400, detail="Please choose a valid subscription plan.")
    interval = str(data.billing_interval or "monthly").strip().lower()
    if interval not in ("monthly", "annual"):
        interval = "monthly"
    if not PAYSTACK_SECRET_KEY:
        raise HTTPException(status_code=503, detail="Payment processing is not configured yet. Please contact support to subscribe.")

    business = db.query(BusinessProfile).filter(BusinessProfile.id == user.business_id).first()
    amount_naira = PLAN_CONFIG[plan]["annual_price" if interval == "annual" else "monthly_price"]
    amount_kobo = int(amount_naira) * 100
    reference = f"cauldra_{business.business_code}_{secrets.token_hex(8)}"

    sub = get_or_create_subscription(db, business)
    record = PaymentRecord(business_id=business.id, subscription_id=sub.id, plan=plan, billing_interval=interval,
                            amount_kobo=amount_kobo, currency="NGN", paystack_reference=reference, status="initialized",
                            transaction_metadata=json.dumps({"business_id": business.id, "plan": plan, "billing_interval": interval}))
    db.add(record); db.commit()

    import requests
    try:
        resp = requests.post(
            "https://api.paystack.co/transaction/initialize",
            headers={"Authorization": f"Bearer {PAYSTACK_SECRET_KEY}", "Content-Type": "application/json"},
            json={"email": business.email or user.email, "amount": amount_kobo, "currency": "NGN", "reference": reference,
                  "callback_url": PAYSTACK_CALLBACK_URL or None,
                  "metadata": {"business_id": business.id, "plan": plan, "billing_interval": interval}},
            timeout=15,
        )
        payload = resp.json()
        if not resp.ok or not payload.get("status"):
            raise RuntimeError(payload.get("message", "Paystack rejected the request."))
    except Exception:
        record.status = "failed"; db.commit()
        raise HTTPException(status_code=502, detail="We couldn't start the payment right now. Please try again.")

    return {"authorization_url": payload["data"]["authorization_url"], "reference": reference, "amount_kobo": amount_kobo}

@app.post("/webhooks/paystack")
async def paystack_webhook(request: Request, db: Session = Depends(get_db)):
    raw_body = await request.body()
    signature = request.headers.get("x-paystack-signature", "")
    if not PAYSTACK_SECRET_KEY:
        raise HTTPException(status_code=503, detail="Payments are not configured.")
    expected = hmac.new(PAYSTACK_SECRET_KEY.encode("utf-8"), raw_body, "sha512").hexdigest()
    if not signature or not hmac.compare_digest(expected, signature):
        raise HTTPException(status_code=401, detail="Invalid webhook signature.")

    event = json.loads(raw_body.decode("utf-8"))
    event_type = event.get("event", "")
    data = event.get("data", {}) or {}
    reference = data.get("reference", "")
    event_key = f"{event_type}:{reference}:{data.get('id', '')}"

    # Paystack retries webhook delivery; never apply the same event twice.
    if db.query(PaystackWebhookEvent).filter(PaystackWebhookEvent.event_key == event_key).first():
        return {"status": "already_processed"}
    db.add(PaystackWebhookEvent(event_key=event_key, event_type=event_type)); db.commit()

    if event_type == "charge.success" and reference:
        record = db.query(PaymentRecord).filter(PaymentRecord.paystack_reference == reference).first()
        if record and record.status != "success":
            record.status = "success"; record.paid_at = datetime.utcnow(); db.commit()
            business = db.query(BusinessProfile).filter(BusinessProfile.id == record.business_id).first()
            sub = get_or_create_subscription(db, business)
            now = datetime.utcnow()
            sub.plan = record.plan; sub.billing_interval = record.billing_interval
            sub.status = "active"; sub.payment_status = "paid"; sub.paid_at = now
            sub.current_period_start = now; sub.current_period_end = add_billing_interval(now, record.billing_interval)
            sub.next_billing_at = sub.current_period_end
            sub.latest_transaction_reference = reference
            business.subscription_plan = record.plan; business.billing_interval = record.billing_interval
            db.commit()
    return {"status": "received"}

def run_billable_ai(db: Session, user: User, operation: str, provider: str, model: str, callback):
    """Record all external-AI outcomes; only successful work consumes credits."""
    try:
        result = callback()
    except Exception:
        record_ai_usage(db, user, operation, False, provider, model)
        db.commit()
        raise
    credits = record_ai_usage(db, user, operation, True, provider, model)
    db.commit()
    return result, credits

@app.post("/ai/suggest-margin")
def suggest_margin(req: MarginRequest, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    text, credits = run_billable_ai(db, user, "margin_advisor", "gemini", GEMINI_MODEL, lambda: gemini_text_response("You are Cauldra's category-aware pricing advisor. Give useful, practical business pricing guidance without inventing facts.", f"Product: {req.name}\nCategory: {req.category}\nCost price: {req.cost_price}\nGive recommended wholesale and retail prices and explain the reasoning briefly."))
    nums=[float(x) for x in re.findall(r"(?<![A-Za-z])(?:\d+(?:\.\d+)?)", text)]
    return {"suggested_wholesale": round(nums[0],2) if nums else round(req.cost_price*1.15,2), "suggested_retail": round(nums[1],2) if len(nums)>1 else round(req.cost_price*1.30,2), "advice": text, "credits_consumed": credits}

@app.post("/ai/scan-invoice")
def scan_invoice(req: InvoiceScanRequest, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    raw_bytes, content_type = decode_base64_upload(req.image_data, {"image/jpeg", "image/png", "image/webp"})
    upload = persist_upload(db, user, "invoice", req.file_name or "invoice-scan", content_type, raw_bytes)
    add_audit(db, user, "INVOICE_UPLOADED", f"Uploaded invoice image {upload.original_name} for review.")
    db.commit()
    data, credits = run_billable_ai(db, user, "invoice_ocr", "openai", OPENAI_MODEL, lambda: openai_json_response(
        "Extract this invoice or receipt into the exact schema. Do not invent values. If uncertain, use empty strings or zero. This endpoint is for review; do not make database mutations yourself.", req.image_data))
    return {"upload_id": upload.id, "supplier_name": data.get("supplier_name") or "", "invoice_number": data.get("invoice_number") or "", "invoice_date": data.get("invoice_date") or "", "items_count": len(data.get("items") or []), "items": data.get("items") or [], "subtotal": data.get("subtotal") or 0, "total": data.get("total") or 0, "requires_confirmation": True, "credits_consumed": credits}

@app.get("/uploads")
def list_uploads(kind: Optional[str] = Query(None), limit: int = Query(50, ge=1, le=200), offset: int = Query(0, ge=0), user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    q = db.query(StoredUpload).filter(StoredUpload.business_id == user.business_id)
    if kind:
        q = q.filter(StoredUpload.kind == kind.strip().lower())
    rows = q.order_by(StoredUpload.created_at.desc()).offset(offset).limit(limit).all()
    return [{"id": r.id, "kind": r.kind, "file_name": r.original_name, "content_type": r.content_type, "size_bytes": r.size_bytes, "uploaded_by_id": r.uploaded_by_id, "created_at": r.created_at.isoformat(), "download_url": f"/uploads/{r.id}/download"} for r in rows]

@app.get("/uploads/{upload_id}/download")
def download_upload(upload_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    row = db.query(StoredUpload).filter(StoredUpload.id == upload_id, StoredUpload.business_id == user.business_id).first()
    if not row:
        raise HTTPException(status_code=404, detail="Uploaded file is unavailable.")
    path = (UPLOAD_STORAGE_DIR / row.storage_key).resolve()
    if UPLOAD_STORAGE_DIR not in path.parents or not path.is_file():
        raise HTTPException(status_code=404, detail="Uploaded file is unavailable.")
    add_audit(db, user, "UPLOADED_FILE_DOWNLOADED", f"Downloaded retained {row.kind} file {row.original_name}.")
    db.commit()
    return FileResponse(str(path), media_type=row.content_type, filename=row.original_name, content_disposition_type="attachment")

@app.get("/ai/insights")
def ai_insights(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    products=db.query(Product).filter(Product.business_id==user.business_id).all()
    snapshot=[{"name":p.name,"category":p.category,"qty":p.quantity,"min":p.min_stock_level,"retail":p.retail_price,"cost":p.cost_price} for p in products]
    insight, credits = run_billable_ai(db, user, "inventory_insight", "gemini", GEMINI_MODEL, lambda: gemini_text_response("You are Cauldra's inventory intelligence engine. Analyze only the provided inventory snapshot and give concise, actionable insights.", json.dumps(snapshot)))
    return {"insight": insight, "credits_consumed": credits}

@app.post("/ai/chat")
def ai_chat(req: ChatRequest, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    products=db.query(Product).filter(Product.business_id==user.business_id).all()
    snapshot=[{"name":p.name,"sku":p.sku,"category":p.category,"qty":p.quantity,"min":p.min_stock_level,"retail":p.retail_price,"cost":p.cost_price} for p in products]
    reply, credits = run_billable_ai(db, user, "chat", "gemini", GEMINI_MODEL, lambda: gemini_text_response("You are Cauldra's business and inventory assistant. Use only the supplied business data. Be practical and concise; state when data is insufficient.", f"User question: {req.message}\nInventory snapshot: {json.dumps(snapshot)}"))
    return {"reply":reply, "credits_consumed": credits}

# -----------------------------------------------------------------------------
# PRODUCTION ROOT / HEALTH
# -----------------------------------------------------------------------------
@app.get("/health")
def health():
    return {"status":"ok","database":"ok","version":app.version,"refresh_enabled":True}

@app.get("/")
def serve_index():
    return FileResponse(str(INDEX_PATH))

# -----------------------------------------------------------------------------
if __name__ == "__main__":
    import uvicorn
    # Production launcher should run without reload. Use an external process manager in production.
    uvicorn.run("main:app", host=os.getenv("HOST", "127.0.0.1"), port=int(os.getenv("PORT", "8000")), reload=False)
